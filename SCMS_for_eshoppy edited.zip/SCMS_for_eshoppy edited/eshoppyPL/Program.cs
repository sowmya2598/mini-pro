﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using eshoppyBAL;
using eshoppyEntities;
using eshoppyExceptions;


namespace eshoppyPL
{
    class Program
    {
        static void Main(string[] args)
        {
            SCMSBal.setList();
            int user;
            do
            {

                UserMenu();
                //Console.WriteLine("Choose your Option:  \nEnter 1 To Login As Admin!  \n Enter 2 for Register as  Dealer! \nEnter 3 for Register as Customer ! \n----------------------------------");
                user = Convert.ToInt32(Console.ReadLine());

                switch (user)
                {

                    case 1:
                        Admin();
                        break;
                    case 2:
                        Dealer();
                        break;
                    case 3:
                        Customer();
                        break;
                    case 4:
                        return;
                    default:
                        break;

                }

            } while ((user > 0 && user < 4));



        }



        private static void Admin()
        {
            int choice;
            do
            {
                AdminMenu();
                Console.WriteLine("******************************************************************************************");
                Console.Write("Enter your Choice :");
                choice = Int32.Parse(Console.ReadLine());
                Console.WriteLine("******************************************************************************************");
                Console.WriteLine();
                switch (choice)
                {
                    case 1:
                        AddProduct();
                        break;
                    case 2:
                        GetAllProducts();
                        break;
                    case 3:
                        GetAllProductOrders();
                        break;
                    case 4:
                        RemoveProduct();
                        break;
                    case 5:
                        CancelProductOrder();
                        break;
                    case 6:
                        UpdateProduct();
                        break;
                    case 7:
                        SearchProduct();
                        break;
                    case 8:
                        SearchProductOrder();
                        break;
                    case 9:
                        GetAllDealers();
                        break;
                    case 10:
                        GetAllCustomers();
                        break;

                    case 11:
                        return;
                    default:
                        break;
                }

            } while ((choice > 0 && choice < 11));
        }


        private static void Dealer()
        {

            int choice;
            do
            {
                DealerMenu();
                Console.WriteLine("******************************************************************************************");
                Console.Write("Enter your Choice :");
                choice = Int32.Parse(Console.ReadLine());
                Console.WriteLine("******************************************************************************************");
                Console.WriteLine();
                switch (choice)
                {
                    case 1:
                        AddProduct();
                        break;
                    case 2:
                        GetAllProducts();
                        break;
                    case 3:
                        GetAllProductOrders();
                        break;
                    case 4:
                        RemoveProduct();
                        break;
                    case 5:
                        CancelProductOrderByDealer();
                        break;
                    case 6:
                        UpdateProduct();
                        break;
                    case 7:
                        SearchProduct();
                        break;
                    case 8:
                        SearchProductOrder();
                        break;
                    case 9:
                        return;
                    default:
                        break;
                }

            } while ((choice > 0 && choice < 9));
        }

        private static void Customer()
        {
            int choice;
            do
            {
                CustomerMenu();
                Console.WriteLine("******************************************************************************************");
                Console.Write("Enter your Choice :");
                choice = Int32.Parse(Console.ReadLine());
                Console.WriteLine("******************************************************************************************");
                Console.WriteLine();
                switch (choice)
                {
                    case 1:
                        GetAllProducts();
                        break;
                    case 2:
                        SearchProduct();
                        break;
                    case 3:
                        PlaceProductOrder();
                        break;
                    case 4:
                        SearchProductOrder();
                        break;
                    case 5:
                        CancelProductOrderByCustomer();
                        break;
                    case 6:
                        return;
                    default:
                        break;
                }

            } while ((choice > 0 && choice < 6));
        }









        private static void UserMenu()
        {
            Console.WriteLine("\n*********** User Login ***********");
            Console.WriteLine("1. Enter 1 To Login As Admin!");
            Console.WriteLine("2. Enter 2 To Login As Dealer");
            Console.WriteLine("3. Enter 3 To Login As Customer");
            Console.WriteLine("4. Enter 4 To Exit");
            Console.WriteLine("******************************************************************************************");
        }

        private static void AdminMenu()
        {
            Console.WriteLine("\n*********** Admin Access ***********");
            Console.WriteLine("1. Add Product Details");
            Console.WriteLine("2. Get All Products Details");
            Console.WriteLine("3. Get All ProductOrders Details");
            Console.WriteLine("4. Remove Product by Id");
            Console.WriteLine("5. Cancel productOrder by Id");
            Console.WriteLine("6. Update Product Details");
            Console.WriteLine("7. Search Product Details");
            Console.WriteLine("8. Search ProductOrder Details");
            Console.WriteLine("9. Get All Dealers Details");
            Console.WriteLine("10. Get All Customers Details");
            Console.WriteLine("11. Exit");
            Console.WriteLine("******************************************************************************************");
        }

        private static void DealerMenu()
        {
            Console.WriteLine("\n*********** Dealer Access ***********");
            Console.WriteLine("1. Add Product Details");
            Console.WriteLine("2. Get All Products Details");
            Console.WriteLine("3. Get All ProductOrders Details");
            Console.WriteLine("4. Remove Product by Id");
            Console.WriteLine("5. Cancel productOrderByDealer by Id");
            Console.WriteLine("6. Update Product Details");
            Console.WriteLine("7. Search Product Details");
            Console.WriteLine("8. Search ProductOrder Details");
            Console.WriteLine("9. Exit");
            Console.WriteLine("******************************************************************************************");
        }

        private static void CustomerMenu()
        {
            Console.WriteLine("\n*********** Customer Access ***********");
            Console.WriteLine("1. Get All Products Details");
            Console.WriteLine("2. Search Product Details");
            Console.WriteLine("3. Place Productorder");
            Console.WriteLine("4. Search ProductOrder Details");
            Console.WriteLine("5. Cancel productOrderByCustomer by Id");
            Console.WriteLine("6. Exit");
            Console.WriteLine("******************************************************************************************");
        }


        private static void AddProduct()
        {

            Products product = new Products();
            try
            {
                Console.Write("Enter Product Id: ");
                product.ProductId = Convert.ToInt32(Console.ReadLine());

                Console.Write("Enter ProductName : ");
                product.ProductName = Console.ReadLine();

                Console.Write("Enter Quantity : ");
                product.Quantity = Convert.ToDouble(Console.ReadLine());

                Console.Write("Enter Price : ");
                product.Price = Convert.ToDouble(Console.ReadLine());

                Console.Write("Enter ProductAddDateTime : ");
                product.ProductAddDateTime = Convert.ToDateTime(Console.ReadLine());


                bool productAdded = SCMSBal.AddProductBAL(product);
                if (productAdded)
                {
                    Console.WriteLine("Product Added Successfully");
                }
                else

                    throw new SCMSException("Product Details not Added");
            }
            catch (SCMSException ce)
            {

                Console.WriteLine(ce.Message);
            }

            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void GetAllProducts()
        {
            try
            {
                List<Products> productList = SCMSBal.GetAllProductsBAL();
                if (productList.Count > 0)
                {
                    Console.WriteLine("---------------------------------------------------------------------");
                    Console.WriteLine("ProductId    ProductName  Quantity   Price  ProductAddDateTime ");
                    Console.WriteLine("---------------------------------------------------------------------");
                    foreach (Products product in productList)
                    {
                        Console.WriteLine($"{product.ProductId} \t {product.ProductName} \t {product.Quantity} \t {product.Price} \t {product.ProductAddDateTime} ");
                    }
                    Console.WriteLine("---------------------------------------------------------------------");
                }
                else
                {
                    throw new SCMSException("Product Details not Available");
                }
            }
            catch (SCMSException se)
            {
                Console.WriteLine(se.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void PlaceProductOrder()
        {
            ProductOrders productorder = new ProductOrders();
            try
            {
                Console.Write("Enter ProductOrder Id: ");
                productorder.ProductOrderId = Convert.ToInt32(Console.ReadLine());

                Console.Write("Enter Product Id: ");
                productorder.ProductId = Convert.ToInt32(Console.ReadLine());

                Console.Write("Enter ExpectedDeliveryDate : ");
                productorder.ExpectedDeliveryDate = Convert.ToDateTime(Console.ReadLine());

                Console.Write("Enter Customer Id: ");
                productorder.CustomerId = Convert.ToInt32(Console.ReadLine());

                Console.Write("Enter Dealer Code: ");
                productorder.DealerCode = Convert.ToInt32(Console.ReadLine());

                Console.Write("Enter DispatchedStatus : ");
                productorder.DispatchedStatus = Console.ReadLine();


                bool productorderPlaced = SCMSBal.PlaceProductOrderBAL(productorder);
                if (productorderPlaced)
                {
                    Console.WriteLine("Product Order Placed Successfully");
                }
                else

                    throw new SCMSException("Product  Order Cannot be Placed");
            }
            catch (SCMSException ce)
            {

                Console.WriteLine(ce.Message);
            }

            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void GetAllProductOrders()
        {
            try
            {
                List<ProductOrders> productorderList = SCMSBal.GetAllProductOrdersBAL();
                if (productorderList.Count > 0)
                {
                    Console.WriteLine("---------------------------------------------------------------------");
                    Console.WriteLine("ProductOrderId    ProductId  ExpectedDeliveryDate   CustomerId  DealerCode  DispatchedStatus ");
                    Console.WriteLine("---------------------------------------------------------------------");
                    foreach (ProductOrders productorder in productorderList)
                    {
                        Console.WriteLine($"{productorder.ProductOrderId} \t {productorder.ProductId} \t {productorder.ExpectedDeliveryDate} \t {productorder.CustomerId} \t {productorder.DealerCode} \t {productorder.DispatchedStatus} ");
                    }
                    Console.WriteLine("---------------------------------------------------------------------");
                }
                else
                {
                    throw new SCMSException("ProductOrder Details not Available");
                }
            }
            catch (SCMSException se)
            {
                Console.WriteLine(se.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void RemoveProduct()
        {
            int id;
            try
            {
                Console.Write("Enter Product ID to be Removed : ");
                id = Convert.ToInt32(Console.ReadLine());
                bool productRemoved = SCMSBal.RemoveProductBAL(id);
                if (productRemoved)
                {
                    Console.WriteLine("Product Removed Successfully");
                }
                else
                    throw new SCMSException("Unable To Remove Product");
            }
            catch (SCMSException se)
            {
                Console.WriteLine(se.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void CancelProductOrder()
        {
            int id;
            try
            {
                Console.Write("Enter ProductOrder ID to be Cancelled : ");
                id = Convert.ToInt32(Console.ReadLine());
                bool productorderCancelled = SCMSBal.CancelProductOrderBAL(id);
                if (productorderCancelled)
                {
                    Console.WriteLine("Product Order Cancelled Successfully (By Admin)");
                }
                else
                    throw new SCMSException("Unable To Cancel Product Order (By Admin)");
            }
            catch (SCMSException se)
            {
                Console.WriteLine(se.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void CancelProductOrderByCustomer()
        {
            int id;
            try
            {
                Console.Write("Enter ProductOrder ID to be Cancelled : ");
                id = Convert.ToInt32(Console.ReadLine());
                bool productorderCancelledByCustomer = SCMSBal.CancelProductOrderByCustomerBAL(id);
                if (productorderCancelledByCustomer)
                {
                    Console.WriteLine("Product Order Cancelled Successfully (By Customer)");
                }
                else
                    throw new SCMSException("Unable To Cancel Product Order (By Customer)");
            }
            catch (SCMSException se)
            {
                Console.WriteLine(se.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void CancelProductOrderByDealer()
        {
            int id;
            try
            {
                Console.Write("Enter ProductOrder ID to be Cancelled : ");
                id = Convert.ToInt32(Console.ReadLine());
                bool productorderCancelledByDealer = SCMSBal.CancelProductOrderByDealerBAL(id);
                if (productorderCancelledByDealer)
                {
                    Console.WriteLine("Product Order Cancelled Successfully (By Dealer)");
                }
                else
                    throw new SCMSException("Unable To Cancel Product Order (By Dealer)");
            }
            catch (SCMSException se)
            {
                Console.WriteLine(se.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void UpdateProduct()
        {
            Products product = new Products();
            try
            {
                Console.Write("Enter ProductId to be Updated : ");
                product.ProductId = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter ProductName to be Updated : ");
                product.ProductName = Console.ReadLine();
                Console.Write("Enter Quantity to be Updated: ");
                product.Quantity = Convert.ToDouble(Console.ReadLine());
                Console.Write("Enter Price to be Updated: ");
                product.Price = Convert.ToDouble(Console.ReadLine());
                Console.Write("Enter ProductAddDateTime : ");
                product.ProductAddDateTime = Convert.ToDateTime(Console.ReadLine());

                //Console.Write("Enter Username : ");
                //customer.Username = Console.ReadLine();
                //Console.Write("Enter Password : ");
                //customer.Password = Console.ReadLine();
                bool productUpdated = SCMSBal.UpdateProductBAL(product);
                if (productUpdated)
                {
                    Console.WriteLine("Product Updated Successfully");
                }
                else
                    throw new SCMSException("Product Details not Updated");
            }
            catch (SCMSException se)
            {
                Console.WriteLine(se.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void SearchProduct()
        {
            int id;
            Products product = null;
            try
            {
                Console.Write("Enter Product ID to be Searched : ");
                id = Convert.ToInt32(Console.ReadLine());
                product = SCMSBal.SearchProductBAL(id);
                if (product != null)
                {
                    Console.WriteLine("ProductId : " + product.ProductId);
                    Console.WriteLine("ProductName : " + product.ProductName);
                    Console.WriteLine("Quantity : " + product.Quantity);
                    Console.WriteLine("Price : " + product.Price);
                    Console.WriteLine("ProductAddDateTime: " + product.ProductAddDateTime);

                    //Console.WriteLine("UserName : " + customer.Username);
                    //Console.WriteLine("Password : " + customer.Password);
                }
                else
                    throw new SCMSException("Product not found");
            }
            catch (SCMSException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void SearchProductOrder()
        {

            int id;
            ProductOrders productorder = null;
            try
            {
                Console.Write("Enter ProductOrder ID to be Searched : ");
                id = Convert.ToInt32(Console.ReadLine());
                productorder = SCMSBal.SearchProductOrderBAL(id);
                if (productorder != null)
                {
                    Console.WriteLine("ProductOrderId : " + productorder.ProductOrderId);
                    Console.WriteLine("ProductId : " + productorder.ProductId);
                    Console.WriteLine("ExpectedDeliveryDate : " + productorder.ExpectedDeliveryDate);
                    Console.WriteLine("CustomerId : " + productorder.CustomerId);
                    Console.WriteLine("DealerCode : " + productorder.DealerCode);
                    Console.WriteLine("DispatchedStatus: " + productorder.DispatchedStatus);

                    //Console.WriteLine("UserName : " + customer.Username);
                    //Console.WriteLine("Password : " + customer.Password);
                }
                else
                    throw new SCMSException("Product not found");
            }
            catch (SCMSException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void RegisterAsDealer()
        {
            Dealers dealer = new Dealers();

            try
            {
                Console.Write("Enter Dealer Code : ");
                dealer.DealerCode = Convert.ToInt32(Console.ReadLine());

                Console.Write("Enter Organization Name : ");
                dealer.OrganizationName = Console.ReadLine();

                Console.Write("Enter Contact Person : ");
                dealer.ContactPerson = Console.ReadLine();

                Console.Write("Enter Contact No : ");
                dealer.ContactNumber = Convert.ToDouble(Console.ReadLine());

                Console.Write("Enter Warehouse Address : ");
                dealer.Address_Warehouse = Console.ReadLine();

                Console.Write("Enter  Delivery Address: ");
                dealer.Address_RegdOffice = Console.ReadLine();

                Console.Write("Enter Official Email : ");
                dealer.OfficialEmail = Console.ReadLine();

                Console.Write("Enter Username : ");
                dealer.Username = Console.ReadLine();

                Console.Write("Enter Password : ");
                dealer.Password = Console.ReadLine();

                bool dealerRegistered = SCMSBal.RegisterAsDealerBAL(dealer);
                if (dealerRegistered)
                {
                    Console.WriteLine("Dealer Registered Successfully");
                }
                else

                    throw new SCMSException("Dealer Details Cannot be Registered");
            }
            catch (SCMSException ce)
            {

                Console.WriteLine(ce.Message);
            }

            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void GetAllDealers()
        {
            try
            {
                List<Dealers> dealerList = SCMSBal.GetAllDealersBAL();
                if (dealerList.Count > 0)
                {
                    Console.WriteLine("---------------------------------------------------------------------");
                    Console.WriteLine("Dealer Code    Organization Name   Contact Person  Contact No  Delivery Address   Address Warehouse   Official Email  Username  Password ");
                    Console.WriteLine("---------------------------------------------------------------------");
                    foreach (Dealers dealer in dealerList)
                    {
                        Console.WriteLine($"{dealer.DealerCode} \t {dealer.OrganizationName} \t {dealer.ContactPerson} \t {dealer.ContactNumber} \t {dealer.Address_Warehouse}  \t { dealer.Address_RegdOffice} \t {dealer.OfficialEmail}  \t {dealer.Username}  \t {dealer.Password} ");
                    }
                    Console.WriteLine("---------------------------------------------------------------------");
                }
                else
                {
                    throw new SCMSException("Dealer Details not Available");
                }
            }
            catch (SCMSException ce)
            {

                Console.WriteLine(ce.Message);
            }

            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void RegisterAsCustomer()
        {
            Customers customer = new Customers();

            try
            {
                Console.Write("Enter Customer ID : ");
                customer.CustomerId = Convert.ToInt32(Console.ReadLine());

                Console.Write("Enter Organization Name : ");
                customer.OrganizationName = Console.ReadLine();

                Console.Write("Enter Contact Person : ");
                customer.ContactPerson = Console.ReadLine();

                Console.Write("Enter Contact No : ");
                customer.ContactNumber = Convert.ToDouble(Console.ReadLine());

                Console.Write("Enter Delivery Address : ");
                customer.DeliveryAddress = Console.ReadLine();

                Console.Write("Enter Official Email : ");
                customer.OfficialEmail = Console.ReadLine();

                Console.Write("Enter Username : ");
                customer.Username = Console.ReadLine();

                Console.Write("Enter Password : ");
                customer.Password = Console.ReadLine();

                bool customerRegistered = SCMSBal.RegisterAsCustomerBAL(customer);
                if (customerRegistered)
                {
                    Console.WriteLine("Customer Registered Successfully");
                }
                else

                    throw new SCMSException("Customer Details Cannot be Registered");
            }
            catch (SCMSException ce)
            {

                Console.WriteLine(ce.Message);
            }

            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void GetAllCustomers()
        {
            try
            {
                List<Customers> customerList = SCMSBal.GetAllCustomersBAL();
                if (customerList.Count > 0)
                {
                    Console.WriteLine("---------------------------------------------------------------------");
                    Console.WriteLine("Customer ID    Organization Name   Contact Person Contact No  Delivery Address  Official Email Username  Password");
                    Console.WriteLine("---------------------------------------------------------------------");
                    foreach (Customers customer in customerList)
                    {
                        Console.WriteLine($"{customer.CustomerId} \t {customer.OrganizationName} \t {customer.ContactPerson} \t {customer.ContactNumber} \t {customer.DeliveryAddress}  \t {customer.OfficialEmail}  \t {customer.Username}  \t {customer.Password} ");
                    }
                    Console.WriteLine("---------------------------------------------------------------------");
                }
                else
                {
                    throw new SCMSException("Customer Details not Available");
                }
            }
            catch (SCMSException ce)
            {

                Console.WriteLine(ce.Message);
            }

            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }


        private static void SetSerialization()
        {
            SCMSBal.SetSerialization();
        }


    }

}

