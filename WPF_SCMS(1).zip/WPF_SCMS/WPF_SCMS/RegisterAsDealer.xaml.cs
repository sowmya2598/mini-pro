﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using eshoppyBL;
using eshoppyEntities;
using eshoppyException;

namespace WPF_SCMS
{
    /// <summary>
    /// Interaction logic for RegisterAsDealer.xaml
    /// </summary>
    public partial class RegisterAsDealer : Page
    {
        public RegisterAsDealer()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Dealers newdealer = new Dealers();
            try
            {

                newdealer.OrganizationName = txtOrganizationName.Text;
                newdealer.ContactPerson = txtContactPerson.Text;
                newdealer.ContactNumber = Convert.ToInt32(txtContactNumber.Text);
                newdealer.Address_Warehouse = txtAddress_Warehouse.Text;
                newdealer.OfficialEmail = txtOfficialEmail.Text;
                newdealer.Address_RegdOffice = txtAddress_RegdOffice.Text;


                if (SCMSBL.RegisterAsDealerBAL(newdealer))
                    MessageBox.Show("Dealer Registered Successfully..!");
                else
                    MessageBox.Show("Cannot Register As Dealer ");
            }
            catch (SCMSException sex)
            {
                MessageBox.Show(sex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
