﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using eshoppyBL;
using eshoppyEntities;
using eshoppyException;


namespace WPF_SCMS
{
    /// <summary>
    /// Interaction logic for MLogin.xaml
    /// </summary>
    public partial class MLogin : Window
    {
        public MLogin()
        {
            InitializeComponent();
        }

        private void BtnLogin_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnRegisterAsDealer_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnRegisterAsCustomer_Click(object sender, RoutedEventArgs e)
        {

        }








        private void BtnAdminLogin_Click(object sender, RoutedEventArgs e)
        {
           
        }

        private void BtnDealerLogin_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnCustomerLogin_Click(object sender, RoutedEventArgs e)
        {

        }








        private void BtnALogin_Click(object sender, RoutedEventArgs e)
        {
            if (txtAUserName.Text == "admin" && txtAPassword.Password == "admin")
            {
                MAdmin adminaccess = new MAdmin();
                adminaccess.Show();
                Close();
            }
            else
            {
                MessageBoxResult result = MessageBox.Show("Invalid User Name or Password..Try again..!!!", "Hospital Management System", MessageBoxButton.YesNoCancel);
                if (result == MessageBoxResult.Yes)
                {
                    LoginPage lpage = new LoginPage();
                    lpage.Show();
                }
                else if (result == MessageBoxResult.No)
                {
                    Close();
                }
            }
        }

        private void BtnDLogin_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnCLogin_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
