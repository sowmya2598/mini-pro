﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using eshoppyBL;
using eshoppyEntities;
using eshoppyException;

namespace WPF_SCMS
{
    /// <summary>
    /// Interaction logic for MRegisterAsDealer.xaml
    /// </summary>
    public partial class MRegisterAsDealer : Window
    {
        public MRegisterAsDealer()
        {
            InitializeComponent();
        }

        private void BtnRegisterAsDealer_Click(object sender, RoutedEventArgs e)
        {

            Dealers newdealer = new Dealers();
            try
            {

                newdealer.OrganizationName = txtOrganizationNameD.Text;
                newdealer.ContactPerson = txtContactPersonD.Text;
                newdealer.ContactNumber = Convert.ToInt32(txtContactNumberD.Text);
                newdealer.Address_Warehouse = txtAddress_Warehouse.Text;
                newdealer.OfficialEmail = txtOfficialEmailD.Text;
                newdealer.Address_RegdOffice = txtAddress_RegdOffice.Text;
                newdealer.Username = txtDealerUserName.Text;
                newdealer.Password = txtDealerPassword.Password;


                if (SCMSBL.RegisterAsDealerBAL(newdealer))
                    MessageBox.Show("Dealer Registered Successfully..!");
                else
                    MessageBox.Show("Cannot Register As Dealer ");
            }
            catch (SCMSException sex)
            {
                MessageBox.Show(sex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void BtnClearDealer_Click(object sender, RoutedEventArgs e)
        {
            txtOrganizationNameD.Clear();
            txtContactPersonD.Clear();
            txtContactNumberD.Clear();
            txtAddress_Warehouse.Clear();
            txtOfficialEmailD.Clear();
            txtAddress_RegdOffice.Clear();
            txtDealerUserName.Clear();
            txtDealerPassword.Clear();
        }

       
        

        
    }
}
