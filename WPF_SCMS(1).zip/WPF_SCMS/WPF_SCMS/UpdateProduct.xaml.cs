﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using eshoppyBL;
using eshoppyEntities;
using eshoppyException;

namespace WPF_SCMS
{
    /// <summary>
    /// Interaction logic for UpdateProduct.xaml
    /// </summary>
    public partial class UpdateProduct : Page
    {
        public UpdateProduct()
        {
            InitializeComponent();
        }

       

        private void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Products productSearched = null;
                if (txtProductName.Text == "")
                    productSearched = SCMSBL.SearchProductBAL(Convert.ToInt32(txtProductId.Text));
                else
                    productSearched = SCMSBL.SearchProductBAL(Convert.ToInt32(txtProductName.Text));
                if (productSearched != null)
                {
                    txtProductName.Text = productSearched.ProductName;
                    txtQuantity.Text = productSearched.Quantity.ToString();
                    txtPrice.Text = productSearched.Price.ToString();
                    cdbProductAddDateTime.DataContext = productSearched.ProductAddDateTime;


                }
                else
                {
                    MessageBox.Show("Product not found");
                }
            }
            catch (SCMSException eex)
            {
                MessageBox.Show(eex.Message);
            }
        }

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Products updateProduct = new Products();
                //if (txtProductId.Text == String.Empty)
                //    MessageBox.Show("Product Id should not be Empty");
               
                updateProduct.ProductName = txtProductName.Text;
                updateProduct.Quantity = Convert.ToInt32(txtQuantity.Text);
                updateProduct.Price = Convert.ToInt32(txtPrice.Text);
                updateProduct.ProductAddDateTime = Convert.ToDateTime(cdbProductAddDateTime.DataContext);
               
                bool productUpdated = SCMSBL.UpdateProductBAL(updateProduct);
                if (productUpdated)
                    MessageBox.Show("Product Details are Updated Successfully");
                else
                    MessageBox.Show("Unable to Update Product Details");
            }
            catch (SCMSException cex)
            {
                Console.WriteLine(cex.Message);
            }
        }
    }
}
