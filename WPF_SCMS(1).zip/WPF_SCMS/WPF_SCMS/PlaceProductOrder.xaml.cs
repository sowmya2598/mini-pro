﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using eshoppyBL;
using eshoppyEntities;
using eshoppyException;

namespace WPF_SCMS
{
    /// <summary>
    /// Interaction logic for PlaceProductOrder.xaml
    /// </summary>
    public partial class PlaceProductOrder : Page
    {
        public PlaceProductOrder()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            ProductOrders newproductorder = new ProductOrders();
            try
            {

                newproductorder.ProductId = Convert.ToInt32(txtProductId.Text); ;
                newproductorder.ExpectedDeliveryDate = Convert.ToDateTime(txtblExpectedDeliveryDate.Text);
                newproductorder.CustomerId = Convert.ToInt32(txtCustomerId.Text);
               
                

                if (SCMSBL.PlaceProductOrderBAL(newproductorder))
                    MessageBox.Show("ProductOrder Placed Successfully..!");
                else
                    MessageBox.Show("Cannot Add Product");
            }
            catch (SCMSException sex)
            {
                MessageBox.Show(sex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
