﻿using eshoppyEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using eshoppyDAL;
using eshoppyException;
using System.Data;
using System.Text.RegularExpressions;
using System.IO;


namespace eshoppyBL
{
    public class SCMSBL     
    {
  

        private static bool ValidateProduct(Products product)
        {
            bool Valid = true;
            StringBuilder errorMessages = new StringBuilder();
            bool isProductId = Regex.IsMatch(product.ProductId.ToString(), "^[0-9]{1,5}$");
            if (!isProductId)
            {
                errorMessages.Append("Product ID must contain not more than 5 digits!");
                Valid = false;
            }
            bool isName = Regex.IsMatch(product.ProductName, "^[A-Z][a-z]");
            if (!isName)
            {
                errorMessages.Append(Environment.NewLine + "ProductName Should Start with Capital Letter");
                Valid = false;
            }

            bool isQuantity = Regex.IsMatch(product.Quantity.ToString(), "^[0-9]{1,3}$");
            if (!isQuantity)
            {
                Valid = false;
                errorMessages.Append("Quantity must be less than 1000!");
            }
            bool isPrice = Regex.IsMatch(product.Price.ToString(), "^[0-9]{1,5}$");
            if (!isPrice)
            {
                errorMessages.Append("Price must be less than 1 Lakh!");
                Valid = false;
            }
            //bool isDateandTimeofProductAdded = Regex.IsMatch(product.DateandTimeofProductAdded, "^[0 - 3][0 - 9]/[0 - 1][0 - 9]/[0 - 9]{ 4} [0-1] [0-9]:[0-5] [0-9]:[0-5] [0-9] [paPA] [Mm]$");
            //if (!isDateandTimeofProductAdded)
            //{
            //    errorMessages.Append("Invalid date and time" + Environment.NewLine);
            //    Valid = false;
            //}

            //bool isUsername = Regex.IsMatch(product.Username, "^([A-Za-z])(?=.@*/d)[A-Za-z/d]{5,}$");
            //if (!isUsername)
            //{
            //    errorMessages.Append(Environment.NewLine + "Username must start with a letter and should contain minimum of 5 characters");
            //    Valid = false;
            //}

            //bool isPassword = Regex.IsMatch(product.Password, "^(?=.*[A-Za-z])(?=.@*/d)[A-Za-z/d]{5,}$");
            //if (!isPassword)
            //{
            //    errorMessages.Append(Environment.NewLine + "Password Should contain minimum 5 characters, atleast one letter , one number and one special character");
            //    Valid = false;
            //}


            if (Valid == false)
            {
                throw new SCMSException(errorMessages.ToString());
            }
            return Valid;
        }

        private static bool ValidateProductOrder(ProductOrders productorder)
        {
            bool Valid = true;
            StringBuilder errorMessages = new StringBuilder();
            bool isProductOrderId = Regex.IsMatch(productorder.ProductOrderId.ToString(), "^[0-9]{1,5}$");
            if (!isProductOrderId)
            {
                errorMessages.Append("ProductOrder ID must contain not more than 5 digits!");
                Valid = false;
            }
            bool isProductId = Regex.IsMatch(productorder.ProductId.ToString(), "^[0-9]{1,5}$");
            if (!isProductId)
            {
                errorMessages.Append("Product ID must contain not more than 5 digits!");
                Valid = false;
            }
            bool isCustomerId = Regex.IsMatch(productorder.CustomerId.ToString(), "^[0-9]{1,5}$");
            if (!isCustomerId)
            {
                errorMessages.Append("CustomerId must contain not more than 5 digits!");
                Valid = false;
            }
            //bool isDealerCode = Regex.IsMatch(productorder.DealerCode.ToString(), "^[0-9]{1,5}$");
            //if (!isDealerCode)
            //{
            //    errorMessages.Append("DealerCode must contain not more than 5 digits!");
            //    Valid = false;
            //}

            //bool isExpectedDeliveryDate = Regex.IsMatch(productorder.ExpectedDeliveryDate, "^[0 - 3][0 - 9]/[0 - 1][0 - 9]/[0 - 9]{ 4} [0-1] [0-9]:[0-5] [0-9]:[0-5] [0-9] [paPA] [Mm]$");
            //if (!isExpectedDeliveryDate)
            //{
            //    errorMessages.Append("Invalid date and time" + Environment.NewLine);
            //    Valid = false;
            //}

            ////bool isUsername = Regex.IsMatch(productorder.Username, "^([A-Za-z])(?=.@*/d)[A-Za-z/d]{5,}$");
            ////if (!isUsername)
            ////{
            ////    errorMessages.Append(Environment.NewLine + "Username must start with a letter and should contain minimum of 5 characters");
            ////    Valid = false;
            ////}

            ////bool isPassword = Regex.IsMatch(productorder.Password, "^(?=.*[A-Za-z])(?=.@*/d)[A-Za-z/d]{5,}$");
            ////if (!isPassword)
            ////{
            ////    errorMessages.Append(Environment.NewLine + "Password Should contain minimum 5 characters, atleast one letter , one number and one special character");
            ////    Valid = false;
            ////}

            //if (productorder.DispatchedStatus == string.Empty)
            //{
            //    errorMessages.Append("DispatchedStatus should be provided\n");
            //    Valid = false;
            //}

            if (Valid == false)
            {
                throw new SCMSException(errorMessages.ToString());
            }
            return Valid;
        }


        private static bool ValidateCustomer(Customers customer)
        {
            bool Valid = true;
            StringBuilder errorMessages = new StringBuilder();
            bool isCustomerId = Regex.IsMatch(customer.CustomerId.ToString(), "^[0-9]{1,5}$");
            if (!isCustomerId)
            {
                errorMessages.Append("Customer ID must contain not more than 5 digits!");
                Valid = false;
            }
            bool isName = Regex.IsMatch(customer.OrganizationName, "^[A-Z][a-z]");
            if (!isName)
            {
                errorMessages.Append(Environment.NewLine + "Organization Name Should Start with Capital Letter");
                Valid = false;
            }
            bool isContactPersonName = Regex.IsMatch(customer.ContactPerson, "^[A-Z][a-z]");
            if (!isContactPersonName)
            {
                Valid = false;
                errorMessages.Append(Environment.NewLine + "Name Should Start with Capital Letter!");
            }
            bool isContactNo = Regex.IsMatch(customer.ContactNumber.ToString(), "[6-9][0-9]{9}");
            if (!isContactNo)
            {
                Valid = false;
                errorMessages.Append("Contact number should start with 6 or 7 or 8 or 9 and it should have exactly 10 digits\n");
            }

            bool isDelAddress = Regex.IsMatch(customer.DeliveryAddress, "^[A-Z][a-z]");
            if (!isDelAddress)
            {
                errorMessages.Append(Environment.NewLine + "Address Should start with Capital Letter");
                Valid = false;
            }
            bool isEmail = Regex.IsMatch(customer.OfficialEmail, @"\A(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)\Z", RegexOptions.IgnoreCase);
            if (!isEmail)
            {
                errorMessages.Append("Email is Invalid!" + Environment.NewLine);
                Valid = false;
            }

            if (customer.Username == string.Empty)
            {
                errorMessages.Append(Environment.NewLine + "Customer Username is required cannnot be blank");
                Valid = false;
            }

            if (customer.Password == string.Empty)
            {
                errorMessages.Append(Environment.NewLine + "Customer Password is required cannnot be blank");
                Valid = false;
            }

            //bool isUsername = Regex.IsMatch(customer.Username, "^([A-Za-z])(?=.@*/d)[A-Za-z/d]{5,}$");
            //if (!isUsername)
            //{
            //    errorMessages.Append(Environment.NewLine + "Username must start with a letter and should contain minimum of 5 characters");
            //    Valid = false;
            //}

            //bool isPassword = Regex.IsMatch(customer.Password, "^(?=.*[A-Za-z])(?=.@*/d)[A-Za-z/d]{5,}$");
            //if (!isPassword)
            //{
            //    errorMessages.Append(Environment.NewLine + "Password Should contain minimum 5 characters, atleast one letter , one number and one special character");
            //    Valid = false;
            //}


            if (!Valid) { throw new SCMSException(errorMessages.ToString()); }
            return Valid;
        }


        private static bool ValidateDealer(Dealers dealer)
        {
            bool Valid = true;
            StringBuilder errorMessages = new StringBuilder();
            bool isDealerCode = Regex.IsMatch(dealer.DealerCode.ToString(), "^[0-9]{1,5}$");
            if (!isDealerCode)
            {
                errorMessages.Append("Dealer code must contain not more than 5 digits!");
                Valid = false;
            }
            bool isOrganizationName = Regex.IsMatch(dealer.OrganizationName, "^[A-Z][a-z]");
            if (!isOrganizationName)
            {
                errorMessages.Append(Environment.NewLine + "Organization Name Should Start with Capital Letter");
                Valid = false;
            }
            bool isContactPersonName = Regex.IsMatch(dealer.ContactPerson, "^[A-Z][a-z]");
            if (!isContactPersonName)
            {
                Valid = false;
                errorMessages.Append(Environment.NewLine + "Name Should Start with Capital Letter!");
            }
            bool isContactNo = Regex.IsMatch(dealer.ContactNumber.ToString(), "[6-9][0-9]{9}");
            if (!isContactNo)
            {
                Valid = false;
                errorMessages.Append("Contact number should start with 6 or 7 or 8 or 9 and it should have exactly 10 digits\n");
            }
            bool isDelAddress = Regex.IsMatch(dealer.Address_Warehouse, "^[A-Z][a-z]");
            if (!isDelAddress)
            {
                errorMessages.Append(Environment.NewLine + "Address Should start with Capital Letter");
                Valid = false;
            }
            bool isEmail = Regex.IsMatch(dealer.OfficialEmail, @"\A(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)\Z", RegexOptions.IgnoreCase);
            if (!isEmail)
            {
                errorMessages.Append("Email is Invalid!" + Environment.NewLine);
                Valid = false;
            }
            if (dealer.Username == string.Empty)
            {
                errorMessages.Append(Environment.NewLine + "Dealer Username is required cannnot be blank");
                Valid = false;
            }

            if (dealer.Password == string.Empty)
            {
                errorMessages.Append(Environment.NewLine + "Dealer Password is required cannnot be blank");
                Valid = false;
            }


            //bool isUsername = Regex.IsMatch(deal.Username, "^([A-Za-z])(?=.@*/d)[A-Za-z/d]{5,}$");
            //if (!isUsername)
            //{
            //    errorMessages.Append(Environment.NewLine + "Username must start with a letter and should contain minimum of 5 characters");
            //    Valid = false;
            //}

            //bool isPassword = Regex.IsMatch(deal.Password, "^(?=.*[A-Za-z])(?=.@*/d)[A-Za-z/d]{5,}$");
            //if (!isPassword)
            //{
            //    errorMessages.Append(Environment.NewLine + "Password Should contain minimum 5 characters, atleast one letter , one number and one special character");
            //    Valid = false;
            //}



            if (!Valid) { throw new SCMSException(errorMessages.ToString()); }
            return Valid;
        }


        public static bool AddProductBAL(Products newProduct)
        {

            bool productAdded = false;
            try
            {
                if (ValidateProduct(newProduct))
                {
                    SCMSDAL scmsDAL = new SCMSDAL();
                    productAdded = scmsDAL.AddProductDAL(newProduct);
                    productAdded = true;
                }
            }
            catch (SCMSException)
            {
                throw;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return productAdded;
        }


        public static List<Products> GetAllProductsBAL()
        {
            List<Products> productList = null;
            try
            {

                productList = SCMSDAL.GetAllProductsDAL();
            }
            catch (SCMSException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return productList;
        }



        //public static bool AddProductByDealerBAL(Products newProduct)
        //{
        //    bool productAdded = false;
        //    try
        //    {
        //        if (ValidateProduct(newProduct))
        //        {
        //            productAdded = SCMSDal.AddProductDAL(newProduct);
        //            productAdded = true;
        //        }
        //    }
        //    catch (SCMSException)
        //    {
        //        throw;
        //    }
        //    catch (SystemException ex)
        //    {
        //        throw ex;
        //    }
        //    return productAdded;
        //}

        //public static List<Products> GetAllProductsByDealerBAL()
        //{
        //    List<Products> productList = null;
        //    try
        //    {
        //        productList = SCMSDal.GetAllProductsDAL();
        //    }
        //    catch (eshoppyExceptions.SCMSException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //    return productList;
        //}

        public static bool PlaceProductOrderBAL(ProductOrders newProductOrder)
        {
            bool productorderPlaced = false;
            try
            {
                if (ValidateProductOrder(newProductOrder))
                {
                    
                    productorderPlaced = SCMSDAL.PlaceProductOrderDAL(newProductOrder);
                    productorderPlaced = true;
                }
            }
            catch (SCMSException)
            {
                throw;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return productorderPlaced;
        }

        public static List<ProductOrders> GetAllProductOrdersBAL()
        {
            List<ProductOrders> productorderList = null;
            try
            {
                productorderList = SCMSDAL.GetAllProductOrdersDAL();
            }
            catch (SCMSException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return productorderList;
        }

        public static bool RemoveProductBAL(int removeProductId)
        {
            bool productRemoved = false;
            try
            {

                if (removeProductId > 0)
                {
                    productRemoved = SCMSDAL.RemoveProductDAL(removeProductId);
                    productRemoved = true;

                }


            }
            catch (SCMSException se)
            {
                throw se;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return productRemoved;
        }

        public static bool CancelProductOrderBAL(int cancelProductOrderId)
        {
            bool productorderCancelled = false;
            try
            {
                if (cancelProductOrderId > 0)
                {
                    productorderCancelled = SCMSDAL.CancelProductOrderDAL(cancelProductOrderId);
                    productorderCancelled = true;
                }


            }
            catch (SCMSException se)
            {
                throw se;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return productorderCancelled;
        }

        public static bool CancelProductOrderByCustomerBAL(int cancelProductOrderIdByCustomer)
        {
            bool productorderCancelledbycustomer = false;
            try
            {
                if (cancelProductOrderIdByCustomer > 0)
                {
                    productorderCancelledbycustomer = SCMSDAL.CancelProductOrderByCustomerDAL(cancelProductOrderIdByCustomer);
                    productorderCancelledbycustomer = true;
                }


            }
            catch (SCMSException se)
            {
                throw se;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return productorderCancelledbycustomer;
        }

        public static bool CancelProductOrderByDealerBAL(int cancelProductOrderIdByDealer)
        {
            bool productorderCancelledbydealer = false;
            try
            {
                if (cancelProductOrderIdByDealer > 0)
                {
                    productorderCancelledbydealer = SCMSDAL.CancelProductOrderByDealerDAL(cancelProductOrderIdByDealer);
                    productorderCancelledbydealer = true;
                }


            }
            catch (SCMSException se)
            {
                throw se;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return productorderCancelledbydealer;
        }

        public static bool UpdateProductBAL(Products updateProduct)
        {
            bool productUpdated = false;
            try
            {
                if (ValidateProduct(updateProduct))
                {
                    productUpdated = SCMSDAL.UpdateProductDAL(updateProduct);
                    productUpdated = true;
                }
                else
                {
                    throw new SCMSException("Please provide valid Product details for update");
                }

            }
            catch (SCMSException se)
            {
                throw se;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return productUpdated;
        }

        //public static bool UpdateProductByDealerBAL(Products updateProductByDealer)
        //{
        //        bool productUpdated = false;
        //            try
        //            {
        //                if (ValidateProduct(updateProduct))
        //                {
        //                    productUpdated = SCMSDal.UpdateProductDAL(updateProduct);
        //                    productUpdated = true;
        //                }
        //                else
        //                {
        //                    throw new SCMSException("Please provide valid Product details for update");
        //}

        //            }
        //            catch (SCMSException se)
        //            {
        //                throw se;
        //            }
        //            catch (SystemException ex)
        //            {
        //                throw ex;
        //            }
        //            return productUpdated;
        //}

        public static Products SearchProductBAL(int searchProductID)
        {
            Products product = null;
            try
            {
                product = SCMSDAL.SearchProductDAL(searchProductID);
            }
            catch (SCMSException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return product;
        }

        public static ProductOrders SearchProductOrderBAL(int searchProductOrderID)
        {
            ProductOrders productorder = null;
            try
            {
                productorder = SCMSDAL.SearchProductOrderDAL(searchProductOrderID);
            }
            catch (SCMSException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return productorder;
        }




        public static bool RegisterAsDealerBAL(Dealers newDealer)
        {
            bool dealerRegistered = false;

            try
            {
                if (ValidateDealer(newDealer))
                {
                    dealerRegistered = SCMSDAL.RegisterAsDealerDAL(newDealer);
                    dealerRegistered = true;
                }
                else
                    throw new SCMSException("Dealer data is invalid");
            }
            catch (SCMSException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return dealerRegistered;
        }

        public static List<Dealers> GetAllDealersBAL()
        {
            List<Dealers> dealerList = null;
            try
            {
                dealerList = SCMSDAL.GetAllDealersDAL();
            }
            catch (SCMSException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dealerList;
        }

        public static bool RegisterAsCustomerBAL(Customers newCustomer)
        {
            bool customerRegistered = false;

            try
            {
                if (ValidateCustomer(newCustomer))
                {
                    customerRegistered = SCMSDAL.RegisterAsCustomerDAL(newCustomer);
                    customerRegistered = true;
                }
                else
                    throw new SCMSException("Customer data is invalid");
            }
            catch (SCMSException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return customerRegistered;
        }

        public static List<Customers> GetAllCustomersBAL()
        {

            List<Customers> customerList = null;
            try
            {
                customerList = SCMSDAL.GetAllCustomersDAL();
            }
            catch (SCMSException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return customerList;
        }

    }
}
