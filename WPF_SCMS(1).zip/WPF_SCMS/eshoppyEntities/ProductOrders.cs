﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eshoppyEntities
{
    public class ProductOrders
    {

        public int ProductOrderId { get; set; }
        public int ProductId { get; set; }
        public DateTime ExpectedDeliveryDate { get; set; }
        public int CustomerId { get; set; }
        public int DealerCode { get; set; }
        public string DispatchedStatus { get; set; }


    }
}
