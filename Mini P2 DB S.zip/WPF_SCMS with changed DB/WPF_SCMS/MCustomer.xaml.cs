﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using eshoppyBL;
using eshoppyEntities;
using eshoppyException;


namespace WPF_SCMS
{
    /// <summary>
    /// Interaction logic for MCustomer.xaml
    /// </summary>
    public partial class MCustomer : Window
    {
        public MCustomer()
        {
            InitializeComponent();
        }




        private void BtnSearchProduct_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Products productSearched = null;
                if (txtProductId.Text != "")
                    productSearched = SCMSBL.SearchProductBAL(txtProductId.Text);
                //else
                //    productSearched = SCMSBL.SearchProductBAL(txtProductName.Text);
                if (productSearched != null)
                {
                    txtProductName.Text = productSearched.ProductName;
                    txtQuantity.Text = productSearched.Quantity.ToString();
                    txtPrice.Text = productSearched.Price.ToString();
                    //   txtProductAddDateTime.Text = productSearched.ProductAddDateTime.ToString();


                }
                else
                {
                    MessageBox.Show("Product not found");
                }
            }
            catch (SCMSException eex)
            {
                MessageBox.Show(eex.Message);
            }
        }

        private void BtnGetProducts_Click(object sender, RoutedEventArgs e)
        {
            cpimage.Visibility = Visibility.Hidden;
            dgProducts.Visibility = Visibility.Visible;
            dgProducts.ItemsSource = SCMSBL.GetAllProductsBAL();
        }

        private void BtnClearProducts_Click(object sender, RoutedEventArgs e)
        {
            txtProductId.Clear();
            txtProductName.Clear();
            txtQuantity.Clear();
            txtPrice.Clear();
          //  txtProductAddDateTime.Text = "";
        }









        private void BtnPlaceProductOrder_Click(object sender, RoutedEventArgs e)
        {
            ProductOrders newproductorder = new ProductOrders();
            try
            {
                //if (txtProductOrderId.Text !=null)
                    //    newproductorder = SCMSBL.PlaceProductOrderBAL(txtProductId.Text);
                    newproductorder.ProductOrderId = txtProductOrderId.Text;
                newproductorder.ProductId = txtProductIdP.Text;
                newproductorder.CustomerId = txtCustomerIdC.Text;
                newproductorder.ExpectedDeliveryDate = DateTime.Now.AddDays(7);

                if (txtProductIdP.Text != null)
                
                // newproductorder.CustomerId =txtCustomerIdC.Text;


                if (SCMSBL.PlaceProductOrderBAL(newproductorder))
                    MessageBox.Show("ProductOrder Placed Successfully..!");
                else
                    MessageBox.Show("Cannot Place ProductOrder");
            }
            catch (SCMSException showex)
            {
                MessageBox.Show(showex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void BtnSearchProductOrder_Click(object sender, RoutedEventArgs e)
        {
           
            

            try
            {
                ProductOrders productorderSearched = null;
                if (txtProductOrderId.Text != "")
                    productorderSearched = SCMSBL.SearchProductOrderBAL(txtProductOrderId.Text);
                //else
                //    productorderSearched = SCMSBL.SearchProductOrderBAL(Convert.ToInt32(txtProductId.Text));
                if (productorderSearched != null)
                {
                    txtProductIdP.Text = productorderSearched.ProductId.ToString();
                   txtCustomerIdC.Text = productorderSearched.CustomerId.ToString();
                   // txtExpectedDeliveryDate.Text = productorderSearched.ExpectedDeliveryDate.ToString();



                }
                else
                {
                    MessageBox.Show("ProductOrder not found");
                }
            }
            catch (SCMSException eex)
            {
                MessageBox.Show(eex.Message);
            }
        }

        private void BtnCancelProductOrder_Click(object sender, RoutedEventArgs e)
        {
            bool productorderCancelled = false;
            try
            {
                ProductOrders productOrderSearched = null;
                if (txtProductOrderId.Text != "")
                {
                    productOrderSearched = SCMSBL.SearchProductOrderBAL(txtProductOrderId.Text);
                    productorderCancelled = SCMSBL.CancelProductOrderBAL(productOrderSearched.ProductOrderId);
                }
                //else if (txtProductId.Text != "")
                //{
                //    productOrderSearched = SCMSBL.SearchProductOrderBAL(txtProductId.Text);
                //    productorderCancelled = SCMSBL.RemoveProductBAL(productOrderSearched.ProductOrderId);
                //}
                if (productorderCancelled)
                    MessageBox.Show("ProductOrder Cancelled Successfully");
                else
                    MessageBox.Show("Unable to Cancel productOrder");
            }
            catch (SCMSException cex)
            {
                MessageBox.Show(cex.Message);
            }
        }

        private void BtnClearProductOrders_Click(object sender, RoutedEventArgs e)
        {
            txtProductOrderId.Clear();
            txtProductIdP.Clear();
            txtCustomerIdC.Clear();
          
           //txtCustomerIdC.Clear();
            //txtExpectedDeliveryDate.Text = "";
        }

       

       

        






        private void BtnLogOutC_Click(object sender, RoutedEventArgs e)
        {
            MLogin obj = new MLogin();
            obj.Show();
            Close();
        }







        //private void GetAllRecords()
        //{
        //    List<Vehicle> vehicles = new List<Vehicle>();
        //    vehicles = OVSBL.GetAllVehiclesForCustomerBL();
        //    dgVehicle.ItemsSource = vehicles.ToList();
        //}


    }
}
