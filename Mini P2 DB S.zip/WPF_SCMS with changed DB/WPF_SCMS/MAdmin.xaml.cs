﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using eshoppyBL;
using eshoppyEntities;
using eshoppyException;


namespace WPF_SCMS
{
    /// <summary>
    /// Interaction logic for MAdmin.xaml
    /// </summary>
    public partial class MAdmin : Window
    {
        public MAdmin()
        {
            InitializeComponent();
        }



///////////////////////////////////////////////////////

        private void BtnAddProduct_Click(object sender, RoutedEventArgs e)
        {
            Products newproduct = new Products();
            try
            {
                newproduct.ProductId = txtProductId.Text;
                newproduct.ProductName = txtProductName.Text;
                newproduct.Quantity = Convert.ToInt32(txtQuantity.Text);
                newproduct.Price = Convert.ToInt32(txtPrice.Text);
                newproduct.ProductAddDateTime = DateTime.Now;
               

                if (SCMSBL.AddProductBAL(newproduct))
                    MessageBox.Show("Product Added Successfully..!");
                else
                    MessageBox.Show("Cannot Add Product");
            }
            catch (SCMSException showex)
            {
                MessageBox.Show(showex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnUpdateProduct_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Products updateProduct = new Products();
                updateProduct.ProductId = txtProductId.Text;
                updateProduct.ProductName = txtProductName.Text;
                updateProduct.Quantity = Convert.ToInt32(txtQuantity.Text);
                updateProduct.Price = Convert.ToInt32(txtPrice.Text);
               updateProduct.ProductAddDateTime = DateTime.Now;

                bool productUpdated = SCMSBL.UpdateProductBAL(updateProduct);
                if (productUpdated)
                    MessageBox.Show("Product Details are Updated Successfully");
                else
                    MessageBox.Show("Unable to Update Product Details");
            }
            catch (SCMSException cex)
            {
                Console.WriteLine(cex.Message);
            }
        }

        private void BtnSearchProduct_Click(object sender, RoutedEventArgs e)
        {
            try
            {

                Products productSearched = null;
                if (txtProductId.Text != null)
                    productSearched = SCMSBL.SearchProductBAL(txtProductId.Text);
                //else
                //    productSearched = SCMSBL.SearchProductBAL(txtProductName.Text);
                if (productSearched != null)
                {
                    txtProductName.Text = productSearched.ProductName;
                    txtQuantity.Text = productSearched.Quantity.ToString();
                    txtPrice.Text = productSearched.Price.ToString();
                  // txtProductAddDateTime.Text = productSearched.ProductAddDateTime.ToShortDateString();


                }
                else
                {
                    MessageBox.Show("Product not found");
                }
            }
            catch (SCMSException eex)
            {
                MessageBox.Show(eex.Message);
            }
        }

        private void BtnRemoveProduct_Click(object sender, RoutedEventArgs e)
        {



           
            try
            {
                bool productRemoved = false;
                Products productsearched = null;
                if(txtProductId.Text!=null)
                {
                    productsearched = SCMSBL.SearchProductBAL(txtProductId.Text);
                    productRemoved = SCMSBL.RemoveProductBAL(txtProductId.Text);
                }

                productRemoved = SCMSBL.RemoveProductBAL(txtProductId.Text);

                if (productRemoved==true)
                    MessageBox.Show("Product Removed Successfully");
                else
                    MessageBox.Show("Unable to remove product");
            }
            catch (SCMSException cex)
            {
                MessageBox.Show(cex.Message);
            }
        }

        private void BtnGetProducts_Click(object sender, RoutedEventArgs e)
        {
            Aproimage.Visibility = Visibility.Hidden;
            dgProducts.ItemsSource = SCMSBL.GetAllProductsBAL();
            dgProducts.Visibility = Visibility.Visible;
        }

        private void BtnClearProducts_Click(object sender, RoutedEventArgs e)
        {
            txtProductId.Clear();
            txtProductName.Clear();
            txtQuantity.Clear();
            txtPrice.Clear();
         // txtProductAddDateTime.Text = "";
        }





        ///////////////////////////


        private void BtnSearchProductOrder_Click(object sender, RoutedEventArgs e)
        {

            try
            {
                ProductOrders productorderSearched = null;
                if (txtProductOrderId.Text !=null)
                    productorderSearched = SCMSBL.SearchProductOrderBAL(txtProductOrderId.Text);
                //else
                //    productorderSearched = SCMSBL.SearchProductOrderBAL(Convert.ToInt32(txtProductId.Text));
                if (productorderSearched != null)
                {
                    txtProductIdP.Text = productorderSearched.ProductId.ToString();
                   txtCustomerIdC.Text = productorderSearched.CustomerId.ToString();
                  // txtExpectedDeliveryDate.Text = productorderSearched.ExpectedDeliveryDate.ToString();



                }
                else
                {
                    MessageBox.Show("ProductOrder not found");
                }
            }
            catch (SCMSException eex)
            {
                MessageBox.Show(eex.Message);
            }
        }

        private void BtnCancelProductOrder_Click(object sender, RoutedEventArgs e)
        {
            bool productorderCancelled = false;
            try
            {
                ProductOrders productOrderSearched = null;
                if (txtProductOrderId.Text != "")
                {
                    productOrderSearched = SCMSBL.SearchProductOrderBAL(txtProductOrderId.Text);
                    productorderCancelled = SCMSBL.CancelProductOrderBAL(productOrderSearched.ProductOrderId);
                }
                //else if (txtProductOrderId.Text != "")
                //{
                //    productOrderSearched = SCMSBL.SearchProductOrderBAL(txtProductOrderId.Text);
                //    productorderCancelled = SCMSBL.RemoveProductBAL(productOrderSearched.ProductOrderId);
                //}
                if (productorderCancelled==true)
                    MessageBox.Show("ProductOrder Cancelled Successfully");
                else
                    MessageBox.Show("Unable to Cancel productOrder");
            }
            catch (SCMSException cex)
            {
                MessageBox.Show(cex.Message);
            }
        }


        private void BtnGetProductOrders_Click(object sender, RoutedEventArgs e)
        {
            apoimage.Visibility = Visibility.Hidden;
            dgProductOrders.Visibility = Visibility.Visible;
            dgProductOrders.ItemsSource = SCMSBL.GetAllProductOrdersBAL();
        }

        private void BtnClearProductOrders_Click(object sender, RoutedEventArgs e)
        {

            txtProductOrderId.Clear();
            txtProductIdP.Clear();
            txtCustomerIdC.Clear();
         
           // txtCustomerIdC.Clear();
           // txtExpectedDeliveryDate.Text = "";
        }



        ///////////////////////////////////////////////////


        //private void BtnSearchCustomer_Click(object sender, RoutedEventArgs e)
        //{
           
        //}

        private void BtnGetCustomers_Click(object sender, RoutedEventArgs e)
        {
            acimage.Visibility = Visibility.Hidden;
            dgCustomers.Visibility = Visibility.Visible;
            dgCustomers.ItemsSource = SCMSBL.GetAllCustomersBAL();
        }

        //private void BtnClearCustomers_Click(object sender, RoutedEventArgs e)
        //{

        //}






        //////////////////

        //private void BtnSearchDealer_Click(object sender, RoutedEventArgs e)
        //{

        //}

        private void BtnGetDealers_Click(object sender, RoutedEventArgs e)
        {
            adimage.Visibility = Visibility.Hidden;
            dgDealers.Visibility = Visibility.Visible;
            dgDealers.ItemsSource = SCMSBL.GetAllDealersBAL();
        }

        //private void BtnClearDealers_Click(object sender, RoutedEventArgs e)
        //{

        //}


        
        /////////////////////////////////////
        

        private void BtnLogOutA_Click(object sender, RoutedEventArgs e)
        {
            MLogin obj = new MLogin();
            obj.Show();
            Close();
        }
    }
}
