﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using eshoppyBL;
using eshoppyEntities;
using eshoppyException;


namespace WPF_SCMS
{
    /// <summary>
    /// Interaction logic for MDealer.xaml
    /// </summary>
    public partial class MDealer : Window
    {
        public MDealer()
        {
            InitializeComponent();
        }

        private void BtnAddProduct_Click(object sender, RoutedEventArgs e)
        {
            Products newproduct = new Products();
            try
            {
                newproduct.ProductId = txtProductId.Text;
                newproduct.ProductName = txtProductName.Text;
                newproduct.Quantity = Convert.ToInt32(txtQuantity.Text);
                newproduct.Price = Convert.ToInt32(txtPrice.Text);
                newproduct.ProductAddDateTime = DateTime.Now;


                if (SCMSBL.AddProductBAL(newproduct))
                    MessageBox.Show("Product Added Successfully..!");
                else
                    MessageBox.Show("Cannot Add Product");
            }
            catch (SCMSException showex)
            {
                MessageBox.Show(showex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnUpdateProduct_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Products updateProduct = new Products();
                updateProduct.ProductId = txtProductId.Text;
                updateProduct.ProductName = txtProductName.Text;
                updateProduct.Quantity = Convert.ToInt32(txtQuantity.Text);
                updateProduct.Price = Convert.ToInt32(txtPrice.Text);
               updateProduct.ProductAddDateTime = DateTime.Now;

                bool productUpdated = SCMSBL.UpdateProductBAL(updateProduct);
                if (productUpdated)
                    MessageBox.Show("Product Details are Updated Successfully");
                else
                    MessageBox.Show("Unable to Update Product Details");
            }
            catch (SCMSException cex)
            {
                Console.WriteLine(cex.Message);
            }
        }

       

        private void BtnSearchProduct_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Products productSearched = null;
                if (txtProductId.Text != "")
                    productSearched = SCMSBL.SearchProductBAL(txtProductId.Text);
                //else
                //    productSearched = SCMSBL.SearchProductBAL(txtProductName.Text);
                if (productSearched != null)
                {
                    txtProductName.Text = productSearched.ProductName;
                    txtQuantity.Text = productSearched.Quantity.ToString();
                    txtPrice.Text = productSearched.Price.ToString();
                //   txtProductAddDateTime.Text = productSearched.ProductAddDateTime.ToString();


                }
                else
                {
                    MessageBox.Show("Product not found");
                }
            }
            catch (SCMSException eex)
            {
                MessageBox.Show(eex.Message);
            }
        }

        private void BtnRemoveProduct_Click(object sender, RoutedEventArgs e)
        {

            try
            {
                bool productRemoved = false;
                Products productsearched = null;
                if (txtProductId.Text != null)
                {
                    productsearched = SCMSBL.SearchProductBAL(txtProductId.Text);
                    productRemoved = SCMSBL.RemoveProductBAL(txtProductId.Text);
                }

                productRemoved = SCMSBL.RemoveProductBAL(txtProductId.Text);

                if (productRemoved == true)
                    MessageBox.Show("Product Removed Successfully");
                else
                    MessageBox.Show("Unable to remove product");
            }
            catch (SCMSException cex)
            {
                MessageBox.Show(cex.Message);
            }
        }
        private void BtnGetProducts_Click(object sender, RoutedEventArgs e)
        {
            dpimage.Visibility = Visibility.Hidden;
            dgProducts.Visibility = Visibility.Visible;
            dgProducts.ItemsSource = SCMSBL.GetAllProductsBAL();

        }

        private void BtnClearProducts_Click(object sender, RoutedEventArgs e)
        {
            txtProductId.Clear();
            txtProductName.Clear();
            txtQuantity.Clear();
            txtPrice.Clear();
          //  txtProductAddDateTime.Text = "";
        }













        private void BtnSearchProductOrder_Click(object sender, RoutedEventArgs e)
        {

            try
            {
                ProductOrders productorderSearched = null;
                if (txtProductOrderId.Text != "")
                    productorderSearched = SCMSBL.SearchProductOrderBAL(txtProductOrderId.Text);
                //else
                //    productorderSearched = SCMSBL.SearchProductOrderBAL(Convert.ToInt32(txtProductId.Text));
                if (productorderSearched != null)
                {
                    txtProductIdP.Text = productorderSearched.ProductId.ToString();
                   txtCustomerIdC.Text = productorderSearched.CustomerId.ToString();
                  // txtExpectedDeliveryDate.Text = productorderSearched.ExpectedDeliveryDate.ToString();



                }
                else
                {
                    MessageBox.Show("ProductOrder not found");
                }
            }
            catch (SCMSException eex)
            {
                MessageBox.Show(eex.Message);
            }
        }

        private void BtnCancelProductOrder_Click(object sender, RoutedEventArgs e)
        {
            bool productorderCancelled = false;
            try
            {
                ProductOrders productOrderSearched = null;
                if (txtProductOrderId.Text != "")
                {
                    productOrderSearched = SCMSBL.SearchProductOrderBAL(txtProductOrderId.Text);
                    productorderCancelled = SCMSBL.CancelProductOrderBAL(productOrderSearched.ProductOrderId);
                }
                //else if (txtProductId.Text != "")
                //{
                //    productOrderSearched = SCMSBL.SearchProductOrderBAL(txtProductIdP.Text);
                //    productorderCancelled = SCMSBL.CancelProductOrderBAL(productOrderSearched.ProductOrderId);
                //}
                if (productorderCancelled)
                    MessageBox.Show("ProductOrder Cancelled Successfully");
                else
                    MessageBox.Show("Unable to Cancel productOrder");
            }
            catch (SCMSException cex)
            {
                MessageBox.Show(cex.Message);
            }
        }

        private void BtnGetProductOrders_Click(object sender, RoutedEventArgs e)
        {
            dpoimage.Visibility = Visibility.Hidden;
            dgProductOrders.Visibility = Visibility.Visible;
            dgProductOrders.ItemsSource = SCMSBL.GetAllProductOrdersBAL();
        }

        private void BtnClearProductOrders_Click(object sender, RoutedEventArgs e)
        {
            txtProductOrderId.Clear();
            txtProductIdP.Clear();
            txtCustomerIdC.Clear();
           
           // txtCustomerIdC.Clear();
          //  txtExpectedDeliveryDate.Text = "";
        }

        




        private void BtnLogOutD_Click(object sender, RoutedEventArgs e)
        {
            MLogin obj = new MLogin();
            obj.Show();
            Close();
        }


        //public void GetAllRecords()
        //{
        //    string email = Application.Current.Properties["DealerEmail"].ToString();
        //    List<Vehicle> vehicles = new List<Vehicle>();
        //    vehicles = OVSBL.GetAllVehiclesForDealerBL(email);
        //    dgDealerVehicle.ItemsSource = vehicles.ToList();
        //}

    }
}
