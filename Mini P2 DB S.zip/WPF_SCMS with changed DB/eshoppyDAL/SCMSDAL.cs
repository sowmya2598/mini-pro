﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using eshoppyEntities;
using System.Data;
using System.Configuration;
using eshoppyException;



namespace eshoppyDAL
{
    public class SCMSDAL
    {

        public bool ValidateCustomerLoginDAL(string username, string password)
        {
            bool isAuthenticated = false;
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["SCMSConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[46008413].SValidateCustomerLogin", objCon);
                objCom.CommandType = CommandType.StoredProcedure;


                objCom.Parameters.AddWithValue("@CUserName", username);
                objCom.Parameters.AddWithValue("@CPassword", password);
                objCom.Connection = objCon;

                objCon.Open();
                SqlDataReader dr = objCom.ExecuteReader();

                if (dr.HasRows)
                {
                    isAuthenticated = true;
                }
            }
            catch (Exception ex)
            {
                throw new SCMSException(ex.Message);
            }

            finally
            {
                objCon.Close();
            }
            return isAuthenticated;
        }

        public bool ValidateDealerLoginDAL(string username, string password)
        {


            bool isAuthenticated = false;
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["SCMSConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[46008413].SValidateDealerLogin", objCon);
                objCom.CommandType = CommandType.StoredProcedure;


                objCom.Parameters.AddWithValue("@DUserName", username);
                objCom.Parameters.AddWithValue("@DPassword", password);
                objCom.Connection = objCon;

                objCon.Open();
                SqlDataReader dr = objCom.ExecuteReader();

                if (dr.HasRows)
                {
                    isAuthenticated = true;
                }
            }
            catch (Exception ex)
            {
                throw new SCMSException(ex.Message);
            }

            finally
            {
                objCon.Close();
            }
            return isAuthenticated;

        }


            public bool AddProductDAL(Products newProduct)
        {
            bool productAdded = false;
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["SCMSConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[46008413].SInsertProduct", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_ProductId = new SqlParameter("@ProductId", newProduct.ProductId);
                SqlParameter objSqlParam_ProductName = new SqlParameter("@ProductName", newProduct.ProductName);
                SqlParameter objSqlParam_Quantity = new SqlParameter("@Quantity", newProduct.Quantity);
                SqlParameter objSqlParam_Price = new SqlParameter("@Price", newProduct.Price);
                SqlParameter objSqlParam_ProductAddDateTime = new SqlParameter("@ProductAddDateTime", newProduct.ProductAddDateTime);
               
                //
                objCom.Parameters.Add(objSqlParam_ProductId);
                objCom.Parameters.Add(objSqlParam_ProductName);
                objCom.Parameters.Add(objSqlParam_Quantity);
                objCom.Parameters.Add(objSqlParam_Price);
               objCom.Parameters.Add(objSqlParam_ProductAddDateTime);
                //
                objCon.Open();
                objCom.ExecuteNonQuery();
                productAdded = true;
            }
            catch (Exception ex)
            {
                throw new SCMSException(ex.Message);
            }
         
            finally
            {
                objCon.Close();
            }
            return productAdded;
        }

        public static List<Products> GetAllProductsDAL()
        {
            List<Products> allProducts = new List<Products>();
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["SCMSConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[46008413].SGetProducts", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                objCon.Open();
                SqlDataReader objDR = objCom.ExecuteReader();
                while (objDR.Read())
                {
                    Products newProduct = new Products();
                   
                    newProduct.ProductId = objDR[0] as string;
                    newProduct.ProductName = objDR[1] as string;
                    newProduct.Quantity = Convert.ToInt32(objDR[2]);
                    newProduct.Price = Convert.ToInt32(objDR[3]);
                    newProduct.ProductAddDateTime = Convert.ToDateTime(objDR[4]);

                   allProducts.Add(newProduct);
                }
            }
            catch (Exception ex)
            {
                throw new SCMSException(ex.Message);
            }

            finally
            {
                objCon.Close();
            }
            return allProducts;
        }
        public static bool PlaceProductOrderDAL(ProductOrders newProductOrder /*, string DealerPOId*/)
        {
            
                bool productorderPlaced = false;
                SqlConnection objCon = null;
                try
                {
                    objCon = new SqlConnection(
                        ConfigurationManager.ConnectionStrings["SCMSConnectionString"].ConnectionString);
                    SqlCommand objCom = new SqlCommand("[46008413].SPlaceProductOrder", objCon);
                    objCom.CommandType = CommandType.StoredProcedure;
                    //
                    SqlParameter objSqlParam_ProductOrderId = new SqlParameter("@ProductOrderId", newProductOrder.ProductOrderId);
                    SqlParameter objSqlParam_ProductId = new SqlParameter("@ProductId", newProductOrder.ProductId);
                    SqlParameter objSqlParam_ExpectedDeliveryDate = new SqlParameter("@ExpectedDeliveryDate", newProductOrder.ExpectedDeliveryDate);
                   SqlParameter objSqlParam_CustomerId = new SqlParameter("@CustomerId", newProductOrder.CustomerId);
               // SqlParameter objSqlParam_DealerCode = new SqlParameter("@DealerCode", newProductOrder.DealerCode);
              
             //  SqlParameter objSqlParam_DispatchedStatus = new SqlParameter("@DispatchedStatus", newProductOrder.DispatchedStatus);

                    //
                    objCom.Parameters.Add(objSqlParam_ProductOrderId);
                    objCom.Parameters.Add(objSqlParam_ProductId);
                    objCom.Parameters.Add(objSqlParam_ExpectedDeliveryDate);
                    objCom.Parameters.Add(objSqlParam_CustomerId);
                //objCom.Parameters.Add(objSqlParam_DealerCode);
             
                //objCom.Parameters.Add(objSqlParam_DispatchedStatus);
                    //
                    objCon.Open();
                    objCom.ExecuteNonQuery();
                productorderPlaced = true;
                }
                catch (Exception ex)
                {
                    throw new SCMSException(ex.Message);
                }

                finally
                {
                    objCon.Close();
                }
                return productorderPlaced;
            }
        public static List<ProductOrders> GetAllProductOrdersDAL()
        {
            List<ProductOrders> allProductOrders = new List<ProductOrders>();
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["SCMSConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[46008413].SGetProductOrders", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                objCon.Open();
                SqlDataReader objDR = objCom.ExecuteReader();
                while (objDR.Read())
                {
                    ProductOrders newProductOrder = new ProductOrders();
                    newProductOrder.ProductOrderId = objDR[0] as string;
                    newProductOrder.ProductId = objDR[1] as string;
                   newProductOrder.ExpectedDeliveryDate = Convert.ToDateTime(objDR[2]) ;
                    newProductOrder.CustomerId = objDR[3] as string;
                    newProductOrder.DealerCode = objDR[4] as string;

                    allProductOrders.Add(newProductOrder);
                }
            }
            catch (Exception ex)
            {
                throw new SCMSException(ex.Message);
            }

            finally
            {
                objCon.Close();
            }
            return allProductOrders;
        }
        public static bool RemoveProductDAL(string removeProductId)
        {
            bool productRemoved = false;
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["SCMSConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[46008413].SRemoveProduct", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_ProductId = new SqlParameter("@ProductId", removeProductId);
                //
                objCom.Parameters.Add(objSqlParam_ProductId);
                //
                objCon.Open();
                objCom.ExecuteNonQuery();
                productRemoved = true;
            }
            catch (Exception ex)
            {
                throw new SCMSException(ex.Message);
            }

            finally
            {
                objCon.Close();
            }
            return productRemoved;
        }
        public static bool CancelProductOrderDAL(string cancelProductOrderId)
        {
            bool productorderCancelled = false;
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["SCMSConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[46008413].SCancelProductOrder", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_ProductOrderId = new SqlParameter("@ProductOrderId", cancelProductOrderId);
                //
                objCom.Parameters.Add(objSqlParam_ProductOrderId);
                //
                objCon.Open();
                objCom.ExecuteNonQuery();
                productorderCancelled = true;
            }
            catch (Exception ex)
            {
                throw new SCMSException(ex.Message);
            }

            finally
            {
                objCon.Close();
            }
            return productorderCancelled;
        }
        //public static bool CancelProductOrderByCustomerDAL(int cancelProductOrderIdByCustomer)
        //{
        //    bool productorderCancelled = false;
        //    SqlConnection objCon = null;
        //    try
        //    {
        //        objCon = new SqlConnection(
        //            ConfigurationManager.ConnectionStrings["SCMSConnectionString"].ConnectionString);
        //        SqlCommand objCom = new SqlCommand("[46008413].CancelProductOrder", objCon);
        //        objCom.CommandType = CommandType.StoredProcedure;
        //        //
        //        SqlParameter objSqlParam_ProductOrderId = new SqlParameter("@ProductOrderId", cancelProductOrderIdByCustomer);
        //        //
        //        objCom.Parameters.Add(objSqlParam_ProductOrderId);
        //        //
        //        objCon.Open();
        //        objCom.ExecuteNonQuery();
        //        productorderCancelled = true;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw new SCMSException(ex.Message);
        //    }

        //    finally
        //    {
        //        objCon.Close();
        //    }
        //    return productorderCancelled;
        //}
        //public static bool CancelProductOrderByDealerDAL(int cancelProductOrderIdByDealer)
        //{
        //    bool productorderCancelled = false;
        //    SqlConnection objCon = null;
        //    try
        //    {
        //        objCon = new SqlConnection(
        //            ConfigurationManager.ConnectionStrings["SCMSConnectionString"].ConnectionString);
        //        SqlCommand objCom = new SqlCommand("[46008413].CancelProductOrder", objCon);
        //        objCom.CommandType = CommandType.StoredProcedure;
        //        //
        //        SqlParameter objSqlParam_ProductOrderId = new SqlParameter("@ProductOrderId", cancelProductOrderIdByDealer);
        //        //
        //        objCom.Parameters.Add(objSqlParam_ProductOrderId);
        //        //
        //        objCon.Open();
        //        objCom.ExecuteNonQuery();
        //        productorderCancelled = true;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw new SCMSException(ex.Message);
        //    }

        //    finally
        //    {
        //        objCon.Close();
        //    }
        //    return productorderCancelled;
        //}
        public static bool UpdateProductDAL(Products updateProduct)
        {
            bool productUpdated = false;
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                     ConfigurationManager.ConnectionStrings["SCMSConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[46008413].SUpdateProduct", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
              //  SqlParameter objSqlParam_PId = new SqlParameter("@PId", updateProduct.PId);
                SqlParameter objSqlParam_ProductId = new SqlParameter("@ProductId", updateProduct.ProductId);
                SqlParameter objSqlParam_ProductName = new SqlParameter("@ProductName", updateProduct.ProductName);
            SqlParameter objSqlParam_Quantity = new SqlParameter("@Quantity", updateProduct.Quantity);
            SqlParameter objSqlParam_Price = new SqlParameter("@Price", updateProduct.Price);
            SqlParameter objSqlParam_ProductAddDateTime = new SqlParameter("@ProductAddDateTime", updateProduct.ProductAddDateTime);

                //
               // objCom.Parameters.Add(objSqlParam_PId);
                objCom.Parameters.Add(objSqlParam_ProductId);
                objCom.Parameters.Add(objSqlParam_ProductName);
            objCom.Parameters.Add(objSqlParam_Quantity);
            objCom.Parameters.Add(objSqlParam_Price);
            objCom.Parameters.Add(objSqlParam_ProductAddDateTime);
            //
            objCon.Open();
            objCom.ExecuteNonQuery();
                productUpdated = true;
        }
            catch (Exception ex)
            {
                throw new SCMSException(ex.Message);
    }
         
            finally
            {
                objCon.Close();
            }
            return productUpdated;
        }
        public static Products SearchProductDAL(string searchProductId)
        {
            Products objProduct = null;
            SqlConnection objCon = null;
            try
            {

                objCon = new SqlConnection(
                     ConfigurationManager.ConnectionStrings["SCMSConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[46008413].SSearchProduct", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //

                SqlParameter objSqlParam_ProductId = new SqlParameter("@ProductId", SqlDbType.VarChar, 50);
                SqlParameter objSqlParam_ProductName = new SqlParameter("@ProductName", SqlDbType.VarChar, 50);
                SqlParameter objSqlParam_Quantity = new SqlParameter("@Quantity", SqlDbType.Int);
                SqlParameter objSqlParam_Price = new SqlParameter("@Price", SqlDbType.Int);
                SqlParameter objSqlParam_ProductAddDateTime = new SqlParameter("@ProductAddDateTime", SqlDbType.DateTime);

                //


                objSqlParam_ProductId.Direction = ParameterDirection.Input;
                objSqlParam_ProductName.Direction = ParameterDirection.Output;
                objSqlParam_Quantity.Direction = ParameterDirection.Output;
                objSqlParam_Price.Direction = ParameterDirection.Output;
                objSqlParam_ProductAddDateTime.Direction = ParameterDirection.Output;

                //
                objCom.Parameters.Add(objSqlParam_ProductId);
                objCom.Parameters.Add(objSqlParam_ProductName);
                objCom.Parameters.Add(objSqlParam_Quantity);
                objCom.Parameters.Add(objSqlParam_Price);
                objCom.Parameters.Add(objSqlParam_ProductAddDateTime);
                //
                objSqlParam_ProductId.Value = searchProductId;
                //
                objCon.Open();
                objCom.ExecuteNonQuery();
                objProduct = new Products();
                objProduct.ProductId = searchProductId;
                objProduct.ProductName = objSqlParam_ProductName.Value as string;
                objProduct.Quantity = Convert.ToInt32(objSqlParam_Quantity.Value);
                objProduct.Price = Convert.ToInt32(objSqlParam_Price.Value);
                objProduct.ProductAddDateTime = Convert.ToDateTime(objSqlParam_ProductAddDateTime.Value);
            }
            catch (Exception ex)
            {
                throw new SCMSException(ex.Message);
            }

            finally
            {
                objCon.Close();
            }
            return objProduct;
        }
        public static ProductOrders SearchProductOrderDAL(string searchProductOrderId)
        {
            ProductOrders objProductOrder = null;
            SqlConnection objCon = null;
            try
            {

                objCon = new SqlConnection(
                     ConfigurationManager.ConnectionStrings["SCMSConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[46008413].SSearchProductOrder", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_ProductOrderId = new SqlParameter("@ProductOrderId", SqlDbType.VarChar, 50);
                SqlParameter objSqlParam_ProductId = new SqlParameter("@ProductId", SqlDbType.VarChar, 50);
              

               SqlParameter objSqlParam_ExpectedDeliveryDate = new SqlParameter("@ExpectedDeliveryDate", SqlDbType.DateTime);
                SqlParameter objSqlParam_CustomerId = new SqlParameter("@CustomerId", SqlDbType.VarChar, 50);
                //  SqlParameter objSqlParam_DealerCode = new SqlParameter("@DealerCode", SqlDbType.Int);
                //SqlParameter objSqlParam_DispatchedStatus = new SqlParameter("@DispatchedStatus", SqlDbType.VarChar, 50);

                //

              
                objSqlParam_ProductOrderId.Direction = ParameterDirection.Input;
                objSqlParam_ProductId.Direction = ParameterDirection.Output;
                objSqlParam_ExpectedDeliveryDate.Direction = ParameterDirection.Output;
                  objSqlParam_CustomerId.Direction = ParameterDirection.Output;
                 //objSqlParam_DealerCode.Direction = ParameterDirection.Output;
               //  objSqlParam_DispatchedStatus.Direction = ParameterDirection.Output;

                //
                objCom.Parameters.Add(objSqlParam_ProductOrderId);
                objCom.Parameters.Add(objSqlParam_ProductId);
            
              
                objCom.Parameters.Add(objSqlParam_ExpectedDeliveryDate);
                objCom.Parameters.Add(objSqlParam_CustomerId);
             //     objCom.Parameters.Add(objSqlParam_DealerCode);
               //  objCom.Parameters.Add(objSqlParam_DispatchedStatus);
                //

                objSqlParam_ProductOrderId.Value = searchProductOrderId;
                //
                objCon.Open();
                objCom.ExecuteNonQuery();

                objProductOrder = new ProductOrders();
                objProductOrder.ProductOrderId = searchProductOrderId;
                objProductOrder.ProductId = objSqlParam_ProductId.Value as string;
            
                objProductOrder.ExpectedDeliveryDate = Convert.ToDateTime(objSqlParam_ExpectedDeliveryDate.Value);
               objProductOrder.CustomerId = objSqlParam_CustomerId.Value as string;
               //objProductOrder.DealerCode = objSqlParam_DealerCode.Value as string;
                //objProductOrder.DispatchedStatus = objSqlParam_DispatchedStatus.Value as string;
            }
            catch (Exception ex)
            {
                throw new SCMSException(ex.Message);
            }

            finally
            {
                objCon.Close();
            }
            return objProductOrder;
        }
        public static bool RegisterAsDealerDAL(Dealers newDealer)
        {

            bool dealerRegistered = false;
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["SCMSConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[46008413].SRegisterAsDealer", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                
                SqlParameter objSqlParam_DealerCode = new SqlParameter("@DealerCode", newDealer.DealerCode);

                SqlParameter objSqlParam_OrganizationName = new SqlParameter("@OrganizationName", newDealer.OrganizationName);
                SqlParameter objSqlParam_ContactPerson = new SqlParameter("@ContactPerson", newDealer.ContactPerson);
                SqlParameter objSqlParam_ContactNumber = new SqlParameter("@ContactNumber", newDealer.ContactNumber);
                SqlParameter objSqlParam_Address_Warehouse = new SqlParameter("@Address_Warehouse", newDealer.Address_Warehouse);
                SqlParameter objSqlParam_OfficialEmail = new SqlParameter("@OfficialEmail", newDealer.OfficialEmail);
                SqlParameter objSqlParam_Address_RegdOffice = new SqlParameter("@Address_RegdOffice", newDealer.Address_RegdOffice);
                SqlParameter objSqlParam_DUsername = new SqlParameter("@DUsername", newDealer.Username);
                SqlParameter objSqlParam_DPassword = new SqlParameter("@DPassword", newDealer.Password);


                //
               objCom.Parameters.Add(objSqlParam_DealerCode);
                objCom.Parameters.Add(objSqlParam_OrganizationName);
                objCom.Parameters.Add(objSqlParam_ContactPerson);
                objCom.Parameters.Add(objSqlParam_ContactNumber);
                objCom.Parameters.Add(objSqlParam_Address_Warehouse);
                objCom.Parameters.Add(objSqlParam_OfficialEmail);
                objCom.Parameters.Add(objSqlParam_Address_RegdOffice);
                objCom.Parameters.Add(objSqlParam_DUsername);
                objCom.Parameters.Add(objSqlParam_DPassword);
                //
                objCon.Open();
                objCom.ExecuteNonQuery();
                dealerRegistered = true;
            }
            catch (Exception ex)
            {
                throw new SCMSException(ex.Message);
            }

            finally
            {
                objCon.Close();
            }
            return dealerRegistered;
        }
        public static List<Dealers> GetAllDealersDAL()
        {
            List<Dealers> allDealers = new List<Dealers>();
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["SCMSConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[46008413].SGetDealers", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                objCon.Open();
                SqlDataReader objDR = objCom.ExecuteReader();
                while (objDR.Read())
                {
                    Dealers newDealer = new Dealers();
                  
                    newDealer.DealerCode = objDR[0] as string;
                    newDealer.OrganizationName = objDR[1] as string;
                    newDealer.ContactPerson = objDR[2] as string;
                    newDealer.ContactNumber = objDR[3] as string;
                    newDealer.Address_Warehouse = objDR[4] as string;
                    newDealer.OfficialEmail = objDR[5] as string;
                    newDealer.Address_RegdOffice = objDR[6] as string;
                    newDealer.Username = objDR[7] as string;
                    newDealer.Password = objDR[8] as string;


                    allDealers.Add(newDealer);
                }
            }
            catch (Exception ex)
            {
                throw new SCMSException(ex.Message);
            }

            finally
            {
                objCon.Close();
            }
            return allDealers;
        }
        public static bool RegisterAsCustomerDAL(Customers newCustomer)
        {
            bool customerRegistered = false;
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["SCMSConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[46008413].SRegisterAsCustomer", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_CustomerId = new SqlParameter("@CustomerId", newCustomer.CustomerId);
                SqlParameter objSqlParam_OrganizationName = new SqlParameter("@OrganizationName", newCustomer.OrganizationName);
                SqlParameter objSqlParam_ContactPerson = new SqlParameter("@ContactPerson", newCustomer.ContactPerson);
                SqlParameter objSqlParam_ContactNumber = new SqlParameter("@ContactNumber", newCustomer.ContactNumber);
                SqlParameter objSqlParam_DeliveryAddress = new SqlParameter("@DeliveryAddress", newCustomer.DeliveryAddress);
                SqlParameter objSqlParam_OfficialEmail = new SqlParameter("@OfficialEmail", newCustomer.OfficialEmail);
                SqlParameter objSqlParam_CUsername = new SqlParameter("@CUsername", newCustomer.Username);
                SqlParameter objSqlParam_CPassword = new SqlParameter("@CPassword", newCustomer.Password);


                //
                objCom.Parameters.Add(objSqlParam_CustomerId);
                objCom.Parameters.Add(objSqlParam_OrganizationName);
                objCom.Parameters.Add(objSqlParam_ContactPerson);
                objCom.Parameters.Add(objSqlParam_ContactNumber);
                objCom.Parameters.Add(objSqlParam_DeliveryAddress);
                objCom.Parameters.Add(objSqlParam_OfficialEmail);
                objCom.Parameters.Add(objSqlParam_CUsername);
                objCom.Parameters.Add(objSqlParam_CPassword);
                //
                objCon.Open();
                objCom.ExecuteNonQuery();
                customerRegistered = true;
            }
            catch (Exception ex)
            {
                throw new SCMSException(ex.Message);
            }

            finally
            {
                objCon.Close();
            }
            return customerRegistered;
        }
        public static List<Customers> GetAllCustomersDAL()
        {
            List<Customers> allCustomers = new List<Customers>();
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["SCMSConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[46008413].SGetCustomers", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                objCon.Open();
                SqlDataReader objDR = objCom.ExecuteReader();
                while (objDR.Read())
                {
                    Customers newCustomer = new Customers();
                   
                    newCustomer.CustomerId = objDR[0] as string;
                    newCustomer.OrganizationName = objDR[1] as string;
                    newCustomer.ContactPerson = objDR[2] as string;
                    newCustomer.ContactNumber = objDR[3] as string;
                    newCustomer.DeliveryAddress = objDR[4] as string;
                    newCustomer.OfficialEmail = objDR[5] as string;
                    newCustomer.Username = objDR[6] as string;
                    newCustomer.Password = objDR[7] as string;


                    allCustomers.Add(newCustomer);
                }
            }
            catch (Exception ex)
            {
                throw new SCMSException(ex.Message);
            }

            finally
            {
                objCon.Close();
            }
            return allCustomers;
        }


        //public static List<Orders> PendingOrdersForAdmin()
        //{

        //}

        //public static List<Orders> PendingOrdersForDealer()
        //{

        //}




        //  // public List<ProductOrders> GetAllProductOrdersForAdminDAL()
        //   {
        //       List<ProductOrders> allProductOrders = new List<ProductOrders>();


        //SqlConnection objCon = null;
        //    try
        //    {
        //        objCon = new SqlConnection(
        //            ConfigurationManager.ConnectionStrings["SCMSConnectionString"].ConnectionString);
        //SqlCommand objCom = new SqlCommand("[46008413].MGetProductOrders", objCon);
        //objCom.CommandType = CommandType.StoredProcedure;
        //        //
        //        objCon.Open();
        //        SqlDataReader objDR = objCom.ExecuteReader();
        //        while (objDR.Read())
        //       {
        //        ProductOrders newProductOrder = new ProductOrders();
        //        newProductOrder.ProductOrderId = objDR[0] as string;
        //                    newProductOrder.ProductId = objDR[1] as string;
        //                    newProductOrder.ExpectedDeliveryDate = Convert.ToDateTime(objDR[2]) ;
        //                    newProductOrder.CustomerId = objDR[3] as string;
        //                    newProductOrder.DealerCode = objDR[4] as string;

        //                    allProductOrders.Add(newProductOrder);
        //                }
        //}
        //            catch (Exception ex)
        //            {
        //                throw new SCMSException(ex.Message);
        //            }

        //            finally
        //            {
        //                objCon.Close();
        //            }
        //            return allProductOrders;
        //   }





        ////   public List<ProductOrders> GetAllProductOrdersForDealerDAL(string DealerCode)
        //   {
        //  List<ProductOrders> allProductOrdersForDealer = new List<ProductOrders>();

        //SqlConnection objCon = null;
        //    int DealerCode = GetDealerPOId(DealerCode);
        //    try
        //    {
        //        objCon = new SqlConnection(
        //            ConfigurationManager.ConnectionStrings["SCMSConnectionString"].ConnectionString);
        //SqlCommand objCom = new SqlCommand("[46008413].MGetProductOrdersForDealer", objCon);
        //  SqlCommand.Parameters.AddWithValue("@DealerPOId", DealerPOId);
        //objCom.CommandType = CommandType.StoredProcedure;
        //        //
        //        objCon.Open();
        //        SqlDataReader objDR = objCom.ExecuteReader();
        //        while (objDR.Read())
        //       {
        //      


        //     
        //      ProductOrders newProductOrder = new ProductOrders();
        //        newProductOrder.ProductOrderId = objDR[0] as string;
        //                    newProductOrder.ProductId = objDR[1] as string;
        //                    newProductOrder.ExpectedDeliveryDate = Convert.ToDateTime(objDR[2]) ;
        //                    newProductOrder.CustomerId = objDR[3] as string;
        //                    newProductOrder.DealerCode = objDR[4] as string;

        //                    allProductOrders.Add(newProductOrder);
        //                }
        //}
        //            catch (Exception ex)
        //            {
        //                throw new SCMSException(ex.Message);
        //            }

        //            finally
        //            {
        //                objCon.Close();
        //            }
        //            return allProductOrders;
        //   }



    }
}

