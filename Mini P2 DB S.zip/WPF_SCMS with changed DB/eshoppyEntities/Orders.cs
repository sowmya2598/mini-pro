﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace eshoppyEntities
{
    public class Orders
    {

        public string ProductOrderId { get; set; }
        public DateTime ProductOrderDate { get; set; }
    }
}
