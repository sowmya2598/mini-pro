use [Training_19Sep19_Pune]
go

create table [46008413].SCustomers
(   
   
    CustomerId varchar(10) not null primary key,
   	OrganizationName  varchar(50)  NOT NULL,
	ContactPerson  varchar(50)  NOT NULL,
	ContactNumber varchar(50)  NOT NULL,
	DeliveryAddress varchar(50)  NOT NULL,
	OfficialEmail varchar(50) NOT NULL,
	CUserName varchar(50) NOT NULL Unique ,
	CPassword varchar(50) NOT NULL,

);





drop table [46008413].SCustomers








create table [46008413].SDealers
(
   
    DealerCode  VARCHAR(10)  not null primary key ,
   	OrganizationName  varchar(50)  NOT NULL,
	ContactPerson  varchar(50)  NOT NULL,
	ContactNumber varchar(50)  NOT NULL,
	Address_Warehouse varchar(50)  NOT NULL,
	OfficialEmail varchar(50) NOT NULL,
	Address_RegdOffice varchar(50)  NOT NULL,
	DUserName varchar(50) NOT NULL Unique ,
	DPassword varchar(50) NOT NULL,

);






drop table [46008413].SDealers









create table [46008413].SProducts
(
  
  ProductId VARCHAR(10) not null  primary key,
  ProductName varchar(50) not null,
  Quantity int not null,
  Price  int not null,
  ProductAddDateTime datetime ,
  );




  drop table [46008413].SProducts





  create table [46008413].SOrders
  (
  ProductOrderId VARCHAR(10) not null primary key,--references [46008413].MOrders ,
  --(POId int identity(1,1) not null,
  -- ProductOrderId AS 'PO' + RIGHT('0000' + CAST(POId AS VARCHAR(10)), 5) persisted primary key,
   ProductOrderDate datetime ,
  );


  
  drop table [46008413].SOrders




create table [46008413].SProductOrders
(
  
   --ProductOrderId  VARCHAR(10) not null primary key,
ProductOrderId VARCHAR(10) references [46008413].SOrders ,
ProductId VARCHAR(10) references [46008413].SProducts ,
ExpectedDeliveryDate  datetime ,
CustomerId VARCHAR(10) references [46008413].SCustomers ,
DealerCode VARCHAR(10) references [46008413].SDealers,
DispatchedStatus char(1) check (DispatchedStatus IN ('Y', 'N'))

);





drop table [46008413].SProductOrders



--------------------------------------------------------------------------------------------------------------------------------------------------------






create PROCEDURE [46008413].SRegisterAsCustomer
	@OrganizationName varchar(50),
	@ContactPerson  varchar(50)  ,
	@ContactNumber varchar(50) ,
	@DeliveryAddress varchar(50) ,
	@OfficialEmail varchar(50) ,
	@CUserName varchar(50)  ,
	@CPassword varchar(50)

As Begin
insert into [46008413].SCustomers
(
OrganizationName ,
ContactPerson  ,
ContactNumber ,
DeliveryAddress  ,
OfficialEmail  ,
CUserName  ,
CPassword 
)

values
(
@OrganizationName ,
@ContactPerson  ,
@ContactNumber ,
@DeliveryAddress  ,
@OfficialEmail  ,
@CUserName  ,
@CPassword 
)
end 
go



create PROCEDURE [46008413].SRegisterAsDealer
	@OrganizationName  varchar(50)  ,
	@ContactPerson  varchar(50),
	@ContactNumber varchar(50)  ,
	@Address_Warehouse varchar(50) ,
	@OfficialEmail varchar(50),
	@Address_RegdOffice varchar(50)  ,
	@DUserName varchar(50)  ,
	@DPassword varchar(50)


As Begin
insert into [46008413].SDealers
(
OrganizationName    ,
	ContactPerson  ,
	ContactNumber   ,
	Address_Warehouse  ,
	OfficialEmail ,
	Address_RegdOffice  ,
	DUserName   ,
	DPassword 
)

values
(
@OrganizationName   ,
	@ContactPerson ,
	@ContactNumber   ,
	@Address_Warehouse ,
	@OfficialEmail ,
	@Address_RegdOffice   ,
	@DUserName  ,
	@DPassword 
)
end 
go


create procedure [46008413].SGetDealers
 As Begin

 select * from [46008413].SDealers
end 
go


create procedure [46008413].SGetCustomers
 As Begin

 select * from [46008413].SCustomers
end 
go



create PROCEDURE [46008413].SInsertProduct
@ProductName varchar(50) ,
@Quantity int ,
@Price  int ,
@ProductAddDateTime  datetime
  As Begin
insert into [46008413].SProducts
(
ProductName  ,
Quantity,
Price   ,
ProductAddDateTime 
)

values
(
@ProductName  ,
@Quantity ,
@Price   ,
@ProductAddDateTime
)
end 
go



create procedure [46008413].SUpdateProduct
@ProductId varchar(10),
@ProductName varchar(50) ,
@Quantity int ,
@Price  int ,
@ProductAddDateTime datetime 

 As Begin
update [46008413].SProducts
set

ProductName = @ProductName,
Quantity=@Quantity,
Price  =@Price ,
ProductAddDateTime =@ProductAddDateTime
where ProductId=@ProductId


end 
go



create procedure [46008413].SSearchProduct
@ProductId varchar(10),
@ProductName varchar(50) output ,
@Quantity int output,
@Price  int output,
@ProductAddDateTime datetime output
 As Begin
select 
@ProductName = ProductName,
@Quantity=Quantity,
@Price  =Price ,
@ProductAddDateTime =ProductAddDateTime

from [46008413].SProducts


where ProductId=@ProductId


end 
go


create procedure [46008413].SRemoveProduct
@ProductId varchar(10)

As Begin
delete [46008413].SProducts
 

where ProductId=@ProductId


end 
go



create procedure [46008413].SGetProducts
 As Begin

 select * from [46008413].SProducts
end 
go




create procedure [46008413].SPlaceProductOrder

@ProductId VARCHAR(10) ,


@ExpectedDeliveryDate  datetime ,
@CustomerId VARCHAR(10) ,
@DealerCode VARCHAR(10) ,
@DispatchedStatus char(1) 
As Begin
insert into [46008413].SProductOrders
(

ProductId ,

ExpectedDeliveryDate ,
CustomerId ,
DealerCode  ,
DispatchedStatus 
)

values
(

@ProductId ,

@ExpectedDeliveryDate,
@CustomerId  ,
@DealerCode  ,
@DispatchedStatus  
)
end 
go




create procedure [46008413].SSearchProductOrder


@ProductId VARCHAR(10) ,
@ProductOrderId VARCHAR(10) output,
@CustomerId VARCHAR(10) output ,

@ExpectedDeliveryDate  datetime output ,
@DealerCode VARCHAR(10) output ,
@DispatchedStatus char(1) output
 As Begin
select 

@ProductOrderId=ProductOrderId ,
@ExpectedDeliveryDate=ExpectedDeliveryDate ,
@CustomerId =CustomerId,
@DealerCode =DealerCode ,
@DispatchedStatus =DispatchedStatus

from [46008413].SProductOrders


where ProductId=@ProductId


end 
go


create procedure [46008413].SCancelProductOrder
@ProductId varchar(10),
@ProductOrderId varchar(10)

As Begin
delete [46008413].MProductOrders
 

where ProductId=@ProductId


end 
go



create procedure [46008413].SGetProductOrders
 As Begin

 select * from [46008413].SProductOrders
end 
go



create procedure [46008413].SInsertOrder

@ProductOrderDate datetime

As Begin
insert into [46008413].SOrders
(
ProductOrderDate
)

values
(
@ProductOrderDate
)
end 
go


create procedure [46008413].SValidateCustomerLogin


@CUserName VARCHAR(50) ,
@CPassword VARCHAR(50) 

As Begin
select * from [46008413].SCustomers where CUserName=@CUserName and CPassword=@CPassword


end 
go
 

create procedure [46008413].SValidateDealerLogin

@DUserName VARCHAR(50) ,
@DPassword VARCHAR(50) 

As Begin
select * from [46008413].SDealers where DUserName=@DUserName and DPassword=@DPassword

--As Begin
--insert into [46008413].MDealers 
--(

--DUserName ,
--DPassword  
 
--)

--values
--(
--@DUserName,
--@DPassword
 
--)
end 
go