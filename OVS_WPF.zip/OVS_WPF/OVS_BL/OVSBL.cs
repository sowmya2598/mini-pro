﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OVS_DAL;
using OVS_Entities;

namespace OVS_BL
{
    public class OVSBL
    {
        public static bool ValidateCustomerLoginBL(string email,string password)
        {
            bool isAunthenticated = false;
            OVSDAL oVSDAL = new OVSDAL();
            isAunthenticated = oVSDAL.ValidateCustomerLoginDAL(email, password);
            return isAunthenticated;
        }

        public static int GetMaxVehicleIdBL()
        {
            OVSDAL oVSDAL = new OVSDAL();
            int VehicleId = oVSDAL.GetMaxVehicleIdDAL();
            return VehicleId;
        }

        public static int GetMaxCustomerId()
        {
            OVSDAL oVSDAL = new OVSDAL();
            int CustomerId = oVSDAL.GetMaxCustomerIdDAL();
            return CustomerId;
        }
        public static int GetMaxDealerId()
        {
            OVSDAL oVSDAL = new OVSDAL();
            int CustomerId = oVSDAL.GetMaxDealerIdDAL();
            return CustomerId;
        }
        public static int GetMaxSalesId()
        {
            OVSDAL oVSDAL = new OVSDAL();
            int CustomerId = oVSDAL.GetMaxSalesIdDAL();
            return CustomerId;
        }
        public static Vehicle SearchVehicleByIdBL(int vehicleId,string email)
        {
            Vehicle vehicle = null;
            OVSDAL oVSDAL = new OVSDAL();
            vehicle = oVSDAL.SearchVehicleByIdDAL(vehicleId, email);
            return vehicle;
        }

        public static bool BuyVehicleBL(Vehicle vehicle,string CustomerEmail)
        {
            bool isPurchased = false;
            OVSDAL oVSDAL = new OVSDAL();
            isPurchased = oVSDAL.BuyVehicleDAL(vehicle, CustomerEmail);
            return isPurchased;
        }

        public static Vehicle SearchVehicleByIdBL(int vehicleId)
        {
            Vehicle vehicle = null;
            OVSDAL oVSDAL = new OVSDAL();
            vehicle = oVSDAL.SearchVehicleByIdDAL(vehicleId);
            return vehicle;
        }

        public static bool AddVehicleBL(Vehicle vehicle, string email)
        {
            bool isAdded = false;
            OVSDAL oVSDAL = new OVSDAL();
            isAdded = oVSDAL.AddVehicleDAL(vehicle, email);
            return isAdded;
        }

        public static bool UpdateVehicleBL(Vehicle vehicle,string email)
        {
            bool isUpdated = false;
            OVSDAL oVSDAL = new OVSDAL();
            if(oVSDAL.UpdateVehicleDAL(vehicle,email))
            {
                isUpdated = true;
            }
            return isUpdated;
        }

        public static bool DeleteVehicleBL(int VehicleId,string Email)
        {
            bool isDeleted = false;
            OVSDAL oVSDAL = new OVSDAL();
            isDeleted = oVSDAL.DeleteVehicleDAL(VehicleId, Email);
            return isDeleted;
        }

        public static List<Vehicle> GetAllVehiclesForCustomerBL()
        {
            List<Vehicle> vehicles = null;
            OVSDAL oVSDAL = new OVSDAL();
            vehicles = oVSDAL.GetAllVehiclesForCustomerDAL();
            return vehicles;
        }

        public static List<Vehicle> GetAllVehiclesForDealerBL(string email)
        {
            List<Vehicle> vehicles = null;
            OVSDAL oVSDAL = new OVSDAL();
            vehicles = oVSDAL.GetAllVehiclesForDealerDAL(email);
            return vehicles;
        }

        public static bool ValidateDealerLoginBL(string email, string password)
        {
            bool isAunthenticated = false;
            OVSDAL oVSDAL = new OVSDAL();
            isAunthenticated = oVSDAL.ValidateDealerLoginDAL(email, password);
            return isAunthenticated;
        }

        public static bool ValidateAdminLoginBL(string email, string password)
        {
            bool isAunthenticated = false;
            OVSDAL oVSDAL = new OVSDAL();
            isAunthenticated = oVSDAL.ValidateAdminLogin_DAL(email, password);
            return isAunthenticated;
        }

        public static bool CustomerSignupBL(string CustomerName,string Gender,string ContactNumber,
            string Email, string Password,string ConfirmPassword,string Address,string City,
            string State,int Pincode)
        {
            bool isRegistered = false;
            OVSDAL oVSDAL = new OVSDAL();
            isRegistered = oVSDAL.CustomerSignupDAL(CustomerName, Gender, ContactNumber, Email, Password, ConfirmPassword,
                   Address, City, State, Pincode);
            return isRegistered;
        }

        public static bool AddCustomerBL(Customer customer)
        {
            bool isAdded = false;
            OVSDAL oVSDAL = new OVSDAL();
            isAdded = oVSDAL.AddCustomerDAL(customer);
            return isAdded;
        }
        public static bool AddDealerBL(Dealer dealer)
        {
            bool isAdded = false;
            OVSDAL oVSDAL = new OVSDAL();
            isAdded = oVSDAL.AddDealerDAL(dealer);
            return isAdded;
        }
        public static bool UpdateCustomerBL(Customer customer)
        {
            bool isUpdated = false;
            OVSDAL oVSDAL = new OVSDAL();
            isUpdated= oVSDAL.UpdateCustomerDAL(customer);
            return isUpdated;
        }
        public static bool UpdateDealerBL(Dealer dealer)
        {
            bool isUpdated = false;
            OVSDAL oVSDAL = new OVSDAL();
            isUpdated = oVSDAL.UpdateDealerDAL(dealer);
            return isUpdated;
        }
        public static bool DeleteCustomerBL(int Customerid)
        {
            bool isUpdated = false;
            OVSDAL oVSDAL = new OVSDAL();
            isUpdated = oVSDAL.DeleteCustomerDAL(Customerid);
            return isUpdated;
        }
        public static bool DeleteDealerBL(int Dealerid)
        {
            bool isUpdated = false;
            OVSDAL oVSDAL = new OVSDAL();
            isUpdated = oVSDAL.DeleteDealerDAL(Dealerid);
            return isUpdated;
        }
        public static Customer SearchCustomerBL(int CustomerId)
        {
            Customer customer = null;
            OVSDAL oVSDAL = new OVSDAL();
            customer = oVSDAL.SearchCustomerDAL(CustomerId);
            return customer;
        }
        public static Dealer SearchDealerBL(int DealerId)
        {
            Dealer dealer = null;
            OVSDAL oVSDAL = new OVSDAL();
            dealer = oVSDAL.SearchDealerDAL(DealerId);
            return dealer;
        }

    }
}
