﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data;
using OVS_Entities;

namespace OVS_DAL
{
    public class OVSDAL
    {
        SqlConnection con;
        SqlCommand cmd;
        public OVSDAL()
        {
            con =
           new SqlConnection(ConfigurationManager.ConnectionStrings["ovsconn"].ConnectionString);
            
        }

        public bool ValidateCustomerLoginDAL(string email,string password)
        {
            bool isAuthenticated = false;

            cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "udp_verifycustomer";
            cmd.Parameters.AddWithValue("@email", email);
            cmd.Parameters.AddWithValue("@password", password);
            cmd.Connection = con;

            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            
            if (dr.HasRows)
            {
                isAuthenticated = true;
            }
            con.Close();
            return isAuthenticated;
        }

        public bool ValidateAdminLogin_DAL(string email, string password)
        {
            bool isAuthenticated = false;

            cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "udp_verifyadmin";
            cmd.Parameters.AddWithValue("@email", email);
            cmd.Parameters.AddWithValue("@password", password);
            cmd.Connection = con;

            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();

            if (dr.HasRows)
            {
                isAuthenticated = true;
            }
            con.Close();
            return isAuthenticated;
        }

        public int GetMaxVehicleIdDAL()
        {
            cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "udp_getmaxvehicleid";
            cmd.Connection = con;
            con.Open();
            int DealerId = (int)cmd.ExecuteScalar();
            return DealerId;
        }

        public int GetMaxCustomerIdDAL()
        {
            cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "udp_getmaxcustomerid";
            cmd.Connection = con;
            con.Open();
            int CustomerId = (int)cmd.ExecuteScalar();
            con.Close();
            return CustomerId;
        }
        public int GetMaxDealerIdDAL()
        {
            cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "udp_getmaxdealerid";
            cmd.Connection = con;
            con.Open();
            int DealerId = (int)cmd.ExecuteScalar();
            con.Close();
            return DealerId;
        }
        public int GetMaxSalesIdDAL()
        {
            cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "udp_getmaxsalesid";
            cmd.Connection = con;
            con.Open();
            int DealerId = (int)cmd.ExecuteScalar();
            con.Close();
            return DealerId;
        }
        public bool AddCustomerDAL(Customer customer)
        {
            bool isAdded = false;
            cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "udp_customersignup";
            cmd.Parameters.AddWithValue("@name", customer.CustomerName);
            cmd.Parameters.AddWithValue("@gender", customer.Gender);
            cmd.Parameters.AddWithValue("@phone", customer.ContactNumber);
            cmd.Parameters.AddWithValue("@email", customer.Email);
            cmd.Parameters.AddWithValue("@password", customer.Password);
            cmd.Parameters.AddWithValue("@confirmpassword", customer.ConfirmPassword);
            cmd.Parameters.AddWithValue("@address", customer.Address);
            cmd.Parameters.AddWithValue("@city", customer.City);
            cmd.Parameters.AddWithValue("@state", customer.State);
            cmd.Parameters.AddWithValue("@pincode", customer.Pincode);
            cmd.Connection = con;

            con.Open();

            int result = cmd.ExecuteNonQuery();

            con.Close();

            if (result > 0)
                isAdded = true;
            return isAdded;
        }
        public bool AddDealerDAL(Dealer dealer)
        {
            bool isAdded = false;
            cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "udp_dealersignup";
            cmd.Parameters.AddWithValue("@DealerId", dealer.DealerId);
            cmd.Parameters.AddWithValue("@DealerName", dealer.DealerName);
            cmd.Parameters.AddWithValue("@CompanyName", dealer.CompanyName);
            cmd.Parameters.AddWithValue("@Email", dealer.Email);
            cmd.Parameters.AddWithValue("@Password", dealer.Password);
            cmd.Parameters.AddWithValue("@ConfirmPassword", dealer.ConfirmPassword);
            cmd.Parameters.AddWithValue("@ContactNo", dealer.ContactNo);
            
            cmd.Connection = con;

            con.Open();

            int result = cmd.ExecuteNonQuery();

            con.Close();

            if (result > 0)
                isAdded = true;
            return isAdded;
        }

        public bool UpdateCustomerDAL(Customer customer)
        {
            bool isUpdated = false;
            cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "udp_updatecustomer";
            cmd.Parameters.AddWithValue("@id", customer.CustomerId);
            cmd.Parameters.AddWithValue("@name", customer.CustomerName);
            cmd.Parameters.AddWithValue("@gender", customer.Gender);
            cmd.Parameters.AddWithValue("@phone", customer.ContactNumber);
            cmd.Parameters.AddWithValue("@email", customer.Email);
            cmd.Parameters.AddWithValue("@password", customer.Password);
            cmd.Parameters.AddWithValue("@confirmpassword", customer.ConfirmPassword);
            cmd.Parameters.AddWithValue("@address", customer.Address);
            cmd.Parameters.AddWithValue("@city", customer.City);
            cmd.Parameters.AddWithValue("@state", customer.State);
            cmd.Parameters.AddWithValue("@pincode", customer.Pincode);
            cmd.Connection = con;

            con.Open();

            int result = cmd.ExecuteNonQuery();

            con.Close();

            if (result > 0)
                isUpdated = true;
            return isUpdated;
        }
        public bool UpdateDealerDAL(Dealer dealer)
        {
            bool isUpdated = false;
            cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "udp_updatedealer";
            cmd.Parameters.AddWithValue("@id", dealer.DealerId);
            cmd.Parameters.AddWithValue("@DealerName", dealer.DealerName);
            cmd.Parameters.AddWithValue("@CompanyName", dealer.CompanyName);
            cmd.Parameters.AddWithValue("@Email", dealer.Email);
            cmd.Parameters.AddWithValue("@Password", dealer.Password);
            cmd.Parameters.AddWithValue("@ConfirmPassword", dealer.ConfirmPassword);
            cmd.Parameters.AddWithValue("@ContactNo", dealer.ContactNo);
            cmd.Connection = con;

            con.Open();

            int result = cmd.ExecuteNonQuery();

            con.Close();

            if (result > 0)
                isUpdated = true;
            return isUpdated;
        }

        public Customer SearchCustomerDAL(int CustomerId)
        {
            Customer customer = null;
            cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "udp_getcustomerbyid";
            cmd.Parameters.AddWithValue("@id", CustomerId);
            cmd.Connection = con;

            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();

            if (dr.HasRows)
            {
                dr.Read();
                customer = new Customer();
                customer.CustomerName = dr.GetString(1);
                customer.Gender = dr.GetString(2);
                customer.ContactNumber = dr.GetString(3);
                customer.Email = dr.GetString(4);
                customer.Password = dr.GetString(5);
                customer.ConfirmPassword = dr.GetString(6);
                customer.Address = dr.GetString(7);
                customer.City = dr.GetString(8);
                customer.State = dr.GetString(9);
                customer.Pincode = dr.GetInt32(10);
            }
            return customer;
        }
        public Dealer SearchDealerDAL(int DealerId)
        {
            Dealer dealer = null;
            cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "udp_getdealerbyid";
            cmd.Parameters.AddWithValue("@id", DealerId);
            cmd.Connection = con;

            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();

            if (dr.HasRows)
            {
                dr.Read();
                dealer = new Dealer();
                dealer.DealerName= dr.GetString(1);
                dealer.CompanyName = dr.GetString(2);
                dealer.Password = dr.GetString(3);
                dealer.ConfirmPassword = dr.GetString(4);
                dealer.Email = dr.GetString(5);
                dealer.ContactNo = dr.GetString(6);
            }
            return dealer;
        }
        public bool DeleteCustomerDAL(int CustomerId)
        {
            bool isDeleted = false;
            cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "udp_deletecustomer";
            cmd.Parameters.AddWithValue("@id", CustomerId);
            cmd.Connection = con;

             cmd.Connection = con;

            con.Open();

            int result = cmd.ExecuteNonQuery();

            con.Close();

            if (result > 0)
                isDeleted = true;
            return isDeleted;
        }
        public bool DeleteDealerDAL(int CustomerId)
        {
            bool isDeleted = false;
            cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "udp_deletedealer";
            cmd.Parameters.AddWithValue("@id", CustomerId);
            cmd.Connection = con;

            cmd.Connection = con;

            con.Open();

            int result = cmd.ExecuteNonQuery();

            con.Close();

            if (result > 0)
                isDeleted = true;
            return isDeleted;
        }

        public int GetDealerId(string email)
        {
            SqlCommand command = new SqlCommand();
            command.CommandType = CommandType.StoredProcedure;
            command.CommandText = "udp_getdealeridbyemail";
            command.Parameters.AddWithValue("@email", email);
            command.Connection = con;
            con.Open();
            int DealerId = (int)command.ExecuteScalar();
            con.Close();
            return DealerId;
        }

        public Vehicle SearchVehicleByIdDAL(int vehicleId,string email)
        {
            Vehicle vehicle = null;


            int DealerId = GetDealerId(email);
            cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "udp_searchvehiclebydealerid";
            cmd.Parameters.AddWithValue("@vehicleid", vehicleId);
            cmd.Parameters.AddWithValue("@dealerid", DealerId);
            cmd.Connection = con;
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            if(dr.HasRows)
            {
                dr.Read();
                vehicle = new Vehicle();
                vehicle.VehicleName = dr.GetString(1);
                vehicle.VehicleModel = dr.GetString(2);
                vehicle.DealerId = dr.GetInt32(3);
                vehicle.Cost = dr.GetDouble(5);
                vehicle.TotalStock = dr.GetInt32(6);
                vehicle.Description = dr.GetString(7);
                vehicle.Rating = dr.GetDouble(8);
            }
            con.Close();
            return vehicle;


        }

        public Vehicle SearchVehicleByIdDAL(int vehicleId)
        {
            Vehicle vehicle = null;
            cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "udp_getvehiclebyid";
            cmd.Parameters.AddWithValue("@id", vehicleId);
            cmd.Connection = con;
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                dr.Read();
                vehicle = new Vehicle();
                vehicle.VehicleName = dr.GetString(1);
                vehicle.VehicleModel = dr.GetString(2);
                vehicle.DealerId = dr.GetInt32(3);
                vehicle.Cost = dr.GetInt32(5);
                vehicle.TotalStock = dr.GetInt32(6);
                vehicle.Description = dr.GetString(7);
                vehicle.Rating = dr.GetInt32(8);
            }
            con.Close();
            return vehicle;
        }

        public bool BuyVehicleDAL(Vehicle vehicle, string CustomerEmail)
        {
            bool isPurchased = false;
            cmd = new SqlCommand();
            int CustomerId = GetCustomerId(CustomerEmail);
            int ShowroomId = GetShowroomId(vehicle.VehicleId);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "udp_buyvehicle";
            cmd.Parameters.AddWithValue("@vehicleid", vehicle.VehicleId);
            cmd.Parameters.AddWithValue("@cost", vehicle.Cost);
            cmd.Parameters.AddWithValue("@orderdate", DateTime.Now);
            cmd.Parameters.AddWithValue("@deliverydate", DateTime.Now.AddDays(1));
            cmd.Parameters.AddWithValue("@customerid", CustomerId);
            cmd.Parameters.AddWithValue("@showroomid", ShowroomId);
            cmd.Connection = con;

            con.Open();
            int AffectedRows = cmd.ExecuteNonQuery();
            con.Close();
            if (AffectedRows > 0)
                isPurchased = true;
            return isPurchased;
        }

        public int GetShowroomId(int VehicleId)
        {
            

            SqlCommand command = new SqlCommand();
            command.CommandType = CommandType.StoredProcedure;
            command.CommandText = "udp_getshowroomidbydealerid";
            command.Parameters.AddWithValue("@dealerid", GetDealerId(VehicleId));
            command.Connection = con;
            con.Open();
            int ShowroomId= (int)command.ExecuteScalar();
            command.Parameters.Clear();
            con.Close();
            return ShowroomId;
        }

        public int GetDealerId(int VehicleId)
        {
            cmd = new SqlCommand();
           
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "udp_getdealeridbyvehicleid";
            cmd.Parameters.AddWithValue("@vehicleid", VehicleId);
            cmd.Connection = con;
            con.Open();
            int DealerId = (int)cmd.ExecuteScalar();
            cmd.Parameters.Clear();
            con.Close();
            return DealerId;
        }

        public int GetCustomerId(string CustomerEmail)
        {
            cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "udp_getcustomeridbyemail";
            cmd.Parameters.AddWithValue("@email", CustomerEmail);
            cmd.Connection = con;
            con.Open();
            int CustomerId= (int)cmd.ExecuteScalar();
            con.Close();
            return CustomerId;
        }

        public bool AddVehicleDAL(Vehicle vehicle, string email)
        {
            bool isAdded = false;
            cmd = new SqlCommand();
            cmd.CommandText = "udp_addvehicle";
            cmd.Connection = con;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@vehiclename", vehicle.VehicleName);
            cmd.Parameters.AddWithValue("@vehiclemodel", vehicle.VehicleModel);
            cmd.Parameters.AddWithValue("@dealerid", GetDealerId(email));
            cmd.Parameters.AddWithValue("@cost", vehicle.Cost);
            cmd.Parameters.AddWithValue("@totalstock", vehicle.TotalStock);
            cmd.Parameters.AddWithValue("@description", vehicle.Description);
            cmd.Parameters.AddWithValue("@rating", vehicle.Rating);
            con.Open();
            int affectedRows = cmd.ExecuteNonQuery();
            con.Close();
            if (affectedRows > 0)
                isAdded = true;
            return isAdded;
        }

        public bool UpdateVehicleDAL(Vehicle vehicle,string email)
        {
            bool isUpdated = false;
            cmd = new SqlCommand();
            cmd.CommandText = "udp_updatevehicle";
            cmd.Connection = con;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@vehicleid", vehicle.VehicleId);
            cmd.Parameters.AddWithValue("@vehiclename", vehicle.VehicleName);
            cmd.Parameters.AddWithValue("@vehiclemodel", vehicle.VehicleModel);
            cmd.Parameters.AddWithValue("@dealerid", GetDealerId(email));
            cmd.Parameters.AddWithValue("@cost", vehicle.Cost);
            cmd.Parameters.AddWithValue("@totalstock", vehicle.TotalStock);
            cmd.Parameters.AddWithValue("@description", vehicle.Description);
            cmd.Parameters.AddWithValue("@rating", vehicle.Rating);
            con.Open();
            int affectedRows = cmd.ExecuteNonQuery();
            con.Close();
            if (affectedRows > 0)
                isUpdated = true;
            
            return isUpdated;
        }

        public bool DeleteVehicleDAL(int VehicleId,string Email)
        {
            bool isDeleted = false;
            cmd = new SqlCommand();
            cmd.CommandText = "udp_deletevehicle";
            cmd.Connection = con;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@vehicleid", VehicleId);
            cmd.Parameters.AddWithValue("dealerid", GetDealerId(Email));
            con.Open();
            int affectedRows = cmd.ExecuteNonQuery();
            con.Close();
            if (affectedRows > 0)
                isDeleted = true;
            return isDeleted;
        }

        public List<Vehicle> GetAllVehiclesForCustomerDAL()
        {
            List<Vehicle> vehicles = new List<Vehicle>();


            
            cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "udp_getallvehicles";
            
            cmd.Connection = con;
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();


            while (dr.Read())
            {
                Vehicle vehicle = new Vehicle();
                vehicle.VehicleId = dr.GetInt32(0);
                vehicle.VehicleName = dr.GetString(1);
                vehicle.VehicleModel = dr.GetString(2);
                vehicle.DealerId = dr.GetInt32(3);
                vehicle.Cost = dr.GetInt32(5);
                vehicle.TotalStock = dr.GetInt32(6);
                vehicle.Description = dr.GetString(7);
                vehicle.Rating = dr.GetInt32(8);

                vehicles.Add(vehicle);
            }
            con.Close();
            return vehicles;
        }

        public List<Vehicle> GetAllVehiclesForDealerDAL(string email)
        {
            List<Vehicle> vehicles = new List<Vehicle>();
            

            int DealerId = GetDealerId(email);
            cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "udp_getvehiclesfordealer";
            cmd.Parameters.AddWithValue("@dealerid", DealerId);
            cmd.Connection = con;
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();

            
            while (dr.Read())
            {
                Vehicle vehicle = new Vehicle();
                vehicle.VehicleId = dr.GetInt32(0);
                vehicle.VehicleName = dr.GetString(1);
                vehicle.VehicleModel = dr.GetString(2);
                vehicle.DealerId = dr.GetInt32(3);
                vehicle.Cost = dr.GetInt32(5);
                vehicle.TotalStock = dr.GetInt32(6);
                vehicle.Description = dr.GetString(7);
                vehicle.Rating = dr.GetInt32(8);

                vehicles.Add(vehicle);
            }
            con.Close();
            return vehicles;
        }

        public bool ValidateDealerLoginDAL(string email, string password)
        {
            bool isAuthenticated = false;

            cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "udp_verifydealer";
            cmd.Parameters.AddWithValue("@email", email);
            cmd.Parameters.AddWithValue("@password", password);
            cmd.Connection = con;

            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();

            if (dr.HasRows)
            {
                isAuthenticated = true;
            }
            con.Close();
            return isAuthenticated;
        }

        public bool CustomerSignupDAL(string CustomerName, string Gender, string ContactNumber,
            string Email, string Password, string ConfirmPassword, string Address, string City,
            string State, int Pincode)
        {
            bool isRegistered = false;
            cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "udp_customersignup";
            cmd.Parameters.AddWithValue("@name", CustomerName);
            cmd.Parameters.AddWithValue("@gender", Gender);
            cmd.Parameters.AddWithValue("@phone", ContactNumber);
            cmd.Parameters.AddWithValue("@email", Email);
            cmd.Parameters.AddWithValue("@password", Password);
            cmd.Parameters.AddWithValue("@confirmpassword", ConfirmPassword);
            cmd.Parameters.AddWithValue("@address", Address);
            cmd.Parameters.AddWithValue("@city", City);
            cmd.Parameters.AddWithValue("@state", State);
            cmd.Parameters.AddWithValue("@pincode", Pincode);
            cmd.Connection = con;

            con.Open();

            int result = cmd.ExecuteNonQuery();

            con.Close();

            if (result > 0)
                isRegistered = true;
            return isRegistered;
        }
    }
}
