﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OVS_Entities
{
    public class Sales
    {
        public int SalesId { get; set; }
        public int VehicleId { get; set; }
        public int CustomerId { get; set; }
        public int ShowroomId { get; set; }
        public int Cost { get; set; }
        public DateTime OrderDate { get; set; }
        public DateTime DeliverDate { get; set; }
        public string Remarks { get; set; }
    }

}

