﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OVS_Entities
{
    public class Vehicle
    {
        public int VehicleId { get; set; }
        public string VehicleName { get; set; }
        public string VehicleModel { get; set; }
        public int DealerId { get; set; }
        public double Cost { get; set; }
        public int TotalStock { get; set; }
        public string Description { get; set; }
        public double Rating { get; set; }
    }
}
