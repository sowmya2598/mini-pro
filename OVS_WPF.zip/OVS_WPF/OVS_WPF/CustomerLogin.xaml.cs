﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using OVS_BL;

namespace OVS_WPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class CustomerLogin : Window
    {
        public CustomerLogin()
        {
            InitializeComponent();
        }

        private void BtnLogin_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string email = txtEmail.Text;
                string password = txtPassword.Text;
                if (OVSBL.ValidateCustomerLoginBL(email, password))
                {
                    CustomerHome customerHome = new CustomerHome();
                    Application.Current.Properties["CustomerEmail"] = email;
                    customerHome.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Invalid UserName Or Password");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnHome_Click(object sender, RoutedEventArgs e)
        {
            OVSHome oVSHome = new OVSHome();
            oVSHome.Show();
            this.Hide();
        }

        private void BtnSignup_Click(object sender, RoutedEventArgs e)
        {
            CustomerSignup customerSignup = new CustomerSignup();
            customerSignup.Show();
            this.Hide();
        }
    }
}
