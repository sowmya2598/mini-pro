﻿using OVS_BL;
using OVS_Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace OVS_WPF
{
    /// <summary>
    /// Interaction logic for CustomerHome.xaml
    /// </summary>
    public partial class CustomerHome : Window
    {
        public CustomerHome()
        {
            InitializeComponent();
        }

        private void BtnHome_Click(object sender, RoutedEventArgs e)
        {
            OVSHome oVSHome = new OVSHome();
            Application.Current.Properties.Remove("CustomerEmail");
            oVSHome.Show();
            this.Hide();

        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            GetAllRecords();
        }

        private void GetAllRecords()
        {
            List<Vehicle> vehicles = new List<Vehicle>();
            vehicles = OVSBL.GetAllVehiclesForCustomerBL();
            dgVehicle.ItemsSource = vehicles.ToList();
        }

        private void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            int VehicleId = int.Parse(txtVehicleId.Text);
           
            Vehicle vehicle = OVSBL.SearchVehicleByIdBL(VehicleId);
            if (vehicle != null)
            {
                txtVehicleName.Text = vehicle.VehicleName;
                txtVehicleModel.Text = vehicle.VehicleModel;
                txtCost.Text = vehicle.Cost.ToString();
                txtTotalStock.Text = vehicle.TotalStock.ToString();
                txtDescription.Text = vehicle.Description;
                txtRating.Text = vehicle.Rating.ToString();
                DisableFields();
            }
            else
            {
                MessageBox.Show("Vehicle Not Available");
                ClearFields();
            }
        }

        private void BtnBuy_Click(object sender, RoutedEventArgs e)
        {
            Vehicle vehicle = new Vehicle();
            vehicle.VehicleId = int.Parse(txtVehicleId.Text);
            vehicle.VehicleName = txtVehicleName.Text;
            vehicle.VehicleModel = txtVehicleModel.Text;
            vehicle.Cost = double.Parse(txtCost.Text);
            vehicle.Description = txtDescription.Text;
            vehicle.TotalStock = int.Parse(txtTotalStock.Text);
            vehicle.Rating = double.Parse(txtRating.Text);
            string CustomerEmail = Application.Current.Properties["CustomerEmail"].ToString();

            if(OVSBL.BuyVehicleBL(vehicle, CustomerEmail))
            {
                MessageBox.Show("Thank You For Purchasing");
                ClearFields();
            }
            else
            {
                MessageBox.Show("Some Error In Purchasing");
                ClearFields();
            }
        }

        private void ClearFields()
        {
            txtVehicleName.Text = "";
            txtVehicleModel.Text = "";
            txtCost.Text = "";
            txtDescription.Text = "";
            txtRating.Text = "";
            txtTotalStock.Text = "";

        }

        private void DisableFields()
        {
            txtVehicleName.IsEnabled = false;
            txtVehicleModel.IsEnabled = false;
            txtCost.IsEnabled = false;
            txtDescription.IsEnabled = false;
            txtRating.IsEnabled = false;
            txtTotalStock.IsEnabled = false;
        }
    }
}
