﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using OVS_BL;
using OVS_Entities;

namespace OVS_WPF
{
    /// <summary>
    /// Interaction logic for DealerHome.xaml
    /// </summary>
    public partial class DealerHome : Window
    {
        public DealerHome()
        {
            InitializeComponent();
        }

        public void GetAllRecords()
        {
            string email = Application.Current.Properties["DealerEmail"].ToString();
            List<Vehicle> vehicles = new List<Vehicle>();
            vehicles = OVSBL.GetAllVehiclesForDealerBL(email);
            dgDealerVehicle.ItemsSource = vehicles.ToList();
        }

        public void Window_loaded(object e,EventArgs args)
        {
            GetAllRecords();
            txtVehicleId.Text = (OVSBL.GetMaxVehicleIdBL()+1).ToString();
            
        }

        private void BtnHome_Click(object sender, RoutedEventArgs e)
        {
            OVSHome oVSHome = new OVSHome();
            Application.Current.Properties.Remove("DealerEmail");
            oVSHome.Show();
            this.Hide();
        }

        private void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            int VehicleId = int.Parse(txtVehicleId.Text);
            string email = Application.Current.Properties["DealerEmail"].ToString();
            Vehicle vehicle = OVSBL.SearchVehicleByIdBL(VehicleId,email);
            if(vehicle!=null)
            {
                txtVehicleName.Text = vehicle.VehicleName;
                txtVehicleModel.Text = vehicle.VehicleModel;
                txtCost.Text = vehicle.Cost.ToString();
                txtTotalStock.Text = vehicle.TotalStock.ToString();
                txtDescription.Text = vehicle.Description;
                txtRating.Text = vehicle.Rating.ToString();
                
            }
            else
            {
                MessageBox.Show("Either Vehicle ID Not Available Or Does Not Belong To You");
                txtVehicleId.Text = (OVSBL.GetMaxVehicleIdBL() + 1).ToString();
            }
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            Vehicle vehicle = new Vehicle();
            vehicle.VehicleName = txtVehicleName.Text;
            vehicle.VehicleModel = txtVehicleModel.Text;
            vehicle.Cost = double.Parse(txtCost.Text);
            vehicle.Description = txtDescription.Text;
            vehicle.TotalStock = int.Parse(txtTotalStock.Text);
            vehicle.Rating = double.Parse(txtRating.Text);
            string email = Application.Current.Properties["DealerEmail"].ToString();

            if(OVSBL.AddVehicleBL(vehicle,email))
            {
                MessageBox.Show("Vehicle Successfully Added");
                GetAllRecords();
                txtVehicleId.Text= (OVSBL.GetMaxVehicleIdBL() + 1).ToString();
                ClearFields();
            }
            else
            {
                MessageBox.Show("Some Error Occured");
            }
        }

        public void ClearFields()
        {
            txtVehicleName.Text = "";
            txtVehicleModel.Text = "";
            txtCost.Text = "";
            txtDescription.Text = "";
            txtRating.Text = "";
            txtTotalStock.Text = "";

        }

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            
            Vehicle vehicle = new Vehicle();
            vehicle.VehicleId = int.Parse(txtVehicleId.Text);
            vehicle.VehicleName = txtVehicleName.Text;
            vehicle.VehicleModel = txtVehicleModel.Text;
            vehicle.Cost = double.Parse(txtCost.Text);
            vehicle.Description = txtDescription.Text;
            vehicle.TotalStock = int.Parse(txtTotalStock.Text);
            vehicle.Rating = double.Parse(txtRating.Text);
            string Email = Application.Current.Properties["DealerEmail"].ToString();
            if(OVSBL.UpdateVehicleBL(vehicle,Email))
            {
                MessageBox.Show("Updated Successfuly");
                GetAllRecords();
                txtVehicleId.Text = (OVSBL.GetMaxVehicleIdBL() + 1).ToString();
                ClearFields();
            }
            else
            {
                MessageBox.Show("Error In Updating The Record");
                txtVehicleId.Text = (OVSBL.GetMaxVehicleIdBL() + 1).ToString();
                ClearFields();
            }
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            int VehicleId = int.Parse(txtVehicleId.Text);
            string Email = Application.Current.Properties["DealerEmail"].ToString();
            if(OVSBL.DeleteVehicleBL(VehicleId,Email))
            {
                MessageBox.Show("Deleted Successfully");
                GetAllRecords();
                ClearFields();
                txtVehicleId.Text = (OVSBL.GetMaxVehicleIdBL() + 1).ToString();
            }
            else
            {
                MessageBox.Show("Either Vehicle ID Not Available Or Does Not Belong To You");
                txtVehicleId.Text = (OVSBL.GetMaxVehicleIdBL() + 1).ToString();
            }
        }
    }
}
