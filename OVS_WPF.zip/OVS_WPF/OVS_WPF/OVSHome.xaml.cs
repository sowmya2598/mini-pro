﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace OVS_WPF
{
    /// <summary>
    /// Interaction logic for OVSHome.xaml
    /// </summary>
    public partial class OVSHome : Window
    {
        public OVSHome()
        {
            InitializeComponent();
        }

        private void btnAdminLogin_Click(object sender, RoutedEventArgs e)
        {
            AdminLogin adminLogin = new AdminLogin();
            adminLogin.Show();
            this.Hide();
        }

        private void btnDealerLogin_Click(object sender, RoutedEventArgs e)
        {
            DealerLogin adminLogin = new DealerLogin();
            adminLogin.Show();
            this.Hide();
        }

        private void btnCustomerLogin_Click(object sender, RoutedEventArgs e)
        {
            CustomerLogin adminLogin = new CustomerLogin();
            adminLogin.Show();
            this.Hide();
        }
    }
}
