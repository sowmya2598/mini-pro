﻿using OVS_BL;
using OVS_Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace OVS_WPF
{
    /// <summary>
    /// Interaction logic for DealerAdmin.xaml
    /// </summary>
    public partial class DealerAdmin : Window
    {
        public DealerAdmin()
        {
            InitializeComponent();
        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            AdminHome adminHome = new AdminHome();
            adminHome.Show();
            this.Hide();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            txtDealerId.Text = (OVSBL.GetMaxDealerId() + 1).ToString();
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
           Dealer dealer = new Dealer();
            dealer.DealerId = int.Parse(txtDealerId.Text);
            dealer.DealerName = txtDealerName.Text;
            dealer.CompanyName = txtCompanyName.Text;
            dealer.Email = txtEmail.Text;
            dealer.ContactNo = txtContactNumber.Text;
            dealer.Password = txtPassword.Text;
            dealer.ConfirmPassword = txtConfirmPassword.Text;

            if (OVSBL.AddDealerBL(dealer))
            {
                MessageBox.Show("Customer Added Successfully");
            }
            else
            {
                MessageBox.Show("Failed To Add Customer");
            }
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            int DealerId = int.Parse(txtDealerId.Text);
            if (OVSBL.DeleteDealerBL(DealerId))
            {
                MessageBox.Show("Customer Deleted Successfully");
            }
            else
            {
                MessageBox.Show("Delete Failed");
            }
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            Dealer dealer = new Dealer();
            dealer.DealerId = int.Parse(txtDealerId.Text);
            dealer.DealerName = txtDealerName.Text;
            dealer.CompanyName = txtCompanyName.Text;
            dealer.Email = txtEmail.Text;
            dealer.ContactNo = txtContactNumber.Text;
            dealer.Password = txtPassword.Text;
            dealer.ConfirmPassword = txtConfirmPassword.Text;

            if (OVSBL.UpdateDealerBL(dealer))
            {
                MessageBox.Show("Customer Updated Successfully");
            }
            else
            {
                MessageBox.Show("Update Failed");
            }
        }

        private void btnClear_Click(object sender, RoutedEventArgs e)
        {
            
            txtDealerName.Text="";
            txtCompanyName.Text="";
            txtEmail.Text = "";
            txtContactNumber.Text = "";
            txtPassword.Text = "";
            txtConfirmPassword.Text = "";
        }

        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            Dealer dealer = null;
            int DealerId = int.Parse(txtDealerId.Text);
            dealer = OVSBL.SearchDealerBL(DealerId);
            if (dealer != null)
            {
                txtDealerName.Text = dealer.DealerName;
                txtCompanyName.Text = dealer.CompanyName;
                txtEmail.Text = dealer.Email;
                txtContactNumber.Text = dealer.ContactNo;
                txtPassword.Text = dealer.Password;
                txtConfirmPassword.Text = dealer.ConfirmPassword;
            }

            else
            {
                MessageBox.Show("Unable To Find Account");
            }
        }
    }
}
