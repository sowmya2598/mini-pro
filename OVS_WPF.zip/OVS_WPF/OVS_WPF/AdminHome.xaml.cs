﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace OVS_WPF
{
    /// <summary>
    /// Interaction logic for AdminHome.xaml
    /// </summary>
    public partial class AdminHome : Window
    {
        public AdminHome()
        {
            InitializeComponent();
        }

        private void BtnHome_Click(object sender, RoutedEventArgs e)
        {
            OVSHome oVSHome = new OVSHome();
            oVSHome.Show();
            this.Hide();
        }

        private void BtnCustomers_Click(object sender, RoutedEventArgs e)
        {
            CustomerAdmin customerAdmin = new CustomerAdmin();
            customerAdmin.Show();
            this.Hide();
        }

        private void BtnVehicles_Click(object sender, RoutedEventArgs e)
        {
            VehicleAdmin vehicleAdmin = new VehicleAdmin();
            vehicleAdmin.Show();
            this.Hide();
        }

        private void BtnShowroom_Click(object sender, RoutedEventArgs e)
        {
            ShowroomAdmin showroomAdmin = new ShowroomAdmin();
            showroomAdmin.Show();
            this.Hide();
        }

        private void BtnDealers_Click(object sender, RoutedEventArgs e)
        {
            DealerAdmin dealerAdmin = new DealerAdmin();
            dealerAdmin.Show();
            this.Hide();
        }

        private void BtnSales_Click(object sender, RoutedEventArgs e)
        {
            SalesAdmin salesAdmin = new SalesAdmin();
            salesAdmin.Show();
            this.Hide();
        }
    }
}
