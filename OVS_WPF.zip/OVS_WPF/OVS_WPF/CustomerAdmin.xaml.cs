﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using OVS_BL;
using OVS_Entities;

namespace OVS_WPF
{
    /// <summary>
    /// Interaction logic for CustomerAdmin.xaml
    /// </summary>
    public partial class CustomerAdmin : Window
    {
        public CustomerAdmin()
        {
            InitializeComponent();
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            AdminHome adminHome = new AdminHome();
            adminHome.Show();
            this.Hide();
        }

        private void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            Customer customer = null;
            int CustomerId = int.Parse(txtCustomerId.Text);
            customer = OVSBL.SearchCustomerBL(CustomerId);
            if (customer != null)
            {
                txtCustomerName.Text = customer.CustomerName;
                cmbGender.DataContext= customer.Gender;
                txtContactNumber.Text = customer.ContactNumber;
                txtEmail.Text = customer.Email;
                txtPassword.Text = customer.Password;
                txtConfirmPassword.Text = customer.ConfirmPassword;
                txtAddress.Text = customer.Address;
                txtCity.Text = customer.City;
                txtState.Text = customer.State;
                txtPincode.Text = customer.Pincode.ToString();
            }

            else
            {
                MessageBox.Show("Unable To Find Account");
            }

        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            Customer customer = new Customer();
            customer.CustomerName = txtCustomerName.Text;
            customer.Gender = cmbGender.SelectedValue.ToString();
            customer.ContactNumber = txtContactNumber.Text;
            customer.Email = txtEmail.Text;
            customer.Password = txtPassword.Text;
            customer.ConfirmPassword = txtConfirmPassword.Text;
            customer.Address = txtAddress.Text;
            customer.City = txtCity.Text;
            customer.State = txtState.Text;
            customer.Pincode = int.Parse(txtPincode.Text);

            if(OVSBL.AddCustomerBL(customer))
            {
                MessageBox.Show("Customer Added Successfully");
            }
            else
            {
                MessageBox.Show("Failed To Add Customer");
            }
        }

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            Customer customer = new Customer();
            customer.CustomerId = int.Parse(txtCustomerId.Text);
            customer.CustomerName = txtCustomerName.Text;
            customer.Gender = cmbGender.SelectedValue.ToString();
            customer.ContactNumber = txtContactNumber.Text;
            customer.Email = txtEmail.Text;
            customer.Password = txtPassword.Text;
            customer.ConfirmPassword = txtConfirmPassword.Text;
            customer.Address = txtAddress.Text;
            customer.City = txtCity.Text;
            customer.State = txtState.Text;
            customer.Pincode = int.Parse(txtPincode.Text);

            if(OVSBL.UpdateCustomerBL(customer))
            {
                MessageBox.Show("Customer Updated Successfully");
            }
            else
            {
                MessageBox.Show("Update Failed");
            }
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            int CustomerId = int.Parse(txtCustomerId.Text);
            if (OVSBL.DeleteCustomerBL(CustomerId))
            {
                MessageBox.Show("Customer Deleted Successfully");
            }
            else
            {
                MessageBox.Show("Delete Failed");
            }

        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            txtCustomerId.Text = (OVSBL.GetMaxCustomerId()+1).ToString();
        }

        private void cmbGender_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void btnClear_Click(object sender, RoutedEventArgs e)
        {
         
            txtCustomerName.Text = "";
            txtContactNumber.Text = "";
            txtPassword.Text = "";
            txtConfirmPassword.Text = "";
            txtEmail.Text = "";
            txtCity.Text = "";
            txtAddress.Text = "";
            txtPincode.Text = "";
            txtState.Text = "";
            
        }
    }
}
