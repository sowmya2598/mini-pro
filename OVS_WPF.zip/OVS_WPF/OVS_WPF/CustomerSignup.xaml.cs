﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using OVS_BL;
using OVS_Entities;

namespace OVS_WPF
{
    /// <summary>
    /// Interaction logic for CustomerSignup.xaml
    /// </summary>
    public partial class CustomerSignup : Window
    {
        public CustomerSignup()
        {
            InitializeComponent();
        }

        private void BtnRegister_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                
                string CustomerName = txtCustomerName.Text;
                string Gender = cmbGender.SelectedItem.ToString();
                string ContactNumber = txtContactNumber.Text;
                string Email = txtEmail.Text;
                string Password = txtPassword.Text;
                string ConfirmPassword = txtConfirmPassword.Text;
                string Address = txtAddress.Text;
                string City = txtCity.Text;
                string State = txtState.Text;
                int Pincode = int.Parse(txtPincode.Text);

                if(OVSBL.CustomerSignupBL(CustomerName, Gender, ContactNumber, Email, Password, ConfirmPassword,
                   Address, City, State, Pincode))
                {
                    MessageBox.Show("You Are Successfully Registered");
                    CustomerLogin customerLogin = new CustomerLogin();
                    customerLogin.Show();
                    this.Hide();
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnHome_Click(object sender, RoutedEventArgs e)
        {
            OVSHome oVSHome = new OVSHome();
            oVSHome.Show();
            this.Hide();
        }
    }
}
