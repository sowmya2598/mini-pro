﻿using OVS_BL;
using OVS_Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace OVS_WPF
{
    /// <summary>
    /// Interaction logic for SalesAdmin.xaml
    /// </summary>
    public partial class SalesAdmin : Window
    {
        public SalesAdmin()
        {
            InitializeComponent();
        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            AdminHome adminHome = new AdminHome();
            adminHome.Show();
            this.Hide();
        }

        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            Sales sales = null;
            int SalesId = int.Parse(txtSalesId.Text);
            sales = OVSBL.SearchSalesBL(SalesId);
            if (sales != null)
            {
              
            }

            else
            {
                MessageBox.Show("Unable To Find Account");
            }

        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            txtSalesId.Text = (OVSBL.GetMaxSalesId() + 1).ToString();
        }
    }
}
