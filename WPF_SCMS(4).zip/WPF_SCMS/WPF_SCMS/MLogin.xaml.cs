﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using eshoppyBL;
using eshoppyEntities;
using eshoppyException;


namespace WPF_SCMS
{
    /// <summary>
    /// Interaction logic for MLogin.xaml
    /// </summary>
    public partial class MLogin : Window
    {
        public MLogin()
        {
            InitializeComponent();
        }

        private void BtnLogin_Click(object sender, RoutedEventArgs e)
        {
            btnAdminLogin.Visibility = Visibility.Visible;
            btnDealerLogin.Visibility = Visibility.Visible;
            btnCustomerLogin.Visibility = Visibility.Visible;
        }

        private void BtnRegisterAsDealer_Click(object sender, RoutedEventArgs e)
        {
            MRegisterAsDealer obj = new MRegisterAsDealer();
            obj.Show();
            Close();
        }

        private void BtnRegisterAsCustomer_Click(object sender, RoutedEventArgs e)
        {

            MRegisterAsCustomer obj = new MRegisterAsCustomer();
            obj.Show();
            Close();
        }








        private void BtnAdminLogin_Click(object sender, RoutedEventArgs e)
        {
            lblAUserName.Visibility = Visibility.Visible;

            lblAPassword.Visibility = Visibility.Visible;

            txtAUserName.Visibility = Visibility.Visible;
            txtAPassword.Visibility = Visibility.Visible;


            btnALogin.Visibility = Visibility.Visible;
        }

        private void BtnDealerLogin_Click(object sender, RoutedEventArgs e)
        {
            lblDUserName.Visibility = Visibility.Visible;

            lblDPassword.Visibility = Visibility.Visible;
            txtDUserName.Visibility = Visibility.Visible;
            txtDPassword.Visibility = Visibility.Visible;


            btnDLogin.Visibility = Visibility.Visible;
        }

        private void BtnCustomerLogin_Click(object sender, RoutedEventArgs e)
        {
            lblCUserName.Visibility = Visibility.Visible;
            lblCPassword.Visibility = Visibility.Visible;
            txtCUserName.Visibility = Visibility.Visible;
            txtCPassword.Visibility = Visibility.Visible;

            btnCLogin.Visibility = Visibility.Visible;
        }








        private void BtnALogin_Click(object sender, RoutedEventArgs e)
        {
            if (txtAUserName.Text == "admin" && txtAPassword.Password == "admin")
            {
                MAdmin adminaccess = new MAdmin();
                adminaccess.Show();
                Close();
            }
            else
            {
                MessageBoxResult result = MessageBox.Show("Invalid User Name or Password..Try again..!!!", "eShoppy Admin Access", MessageBoxButton.YesNoCancel);
                if (result == MessageBoxResult.Yes)
                {
                    MLogin lpage = new MLogin();
                    lpage.Show();
                }
                else if (result == MessageBoxResult.No)
                {
                    Close();
                }
            }
        }

        private void BtnDLogin_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string username = txtDUserName.Text;
                string password = txtDPassword.Password;
                if (SCMSBL.ValidateDealerLoginBL(username, password))
                {
                    MDealer dealeraccess = new MDealer();
                    dealeraccess.Show();

                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Invalid UserName Or Password");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnCLogin_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string username = txtCUserName.Text;
                string password = txtCPassword.Password;
                if (SCMSBL.ValidateCustomerLoginBL(username, password))
                {
                    MCustomer dealeraccess = new MCustomer();
                    dealeraccess.Show();

                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Invalid UserName Or Password");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
