﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace eshoppyEntities
{
    public class Orders
    {
        public int POId { get; set; }
        public string ProductOrderId { get; set; }
        public DateTime ProductOrderDate { get; set; }
    }
}
