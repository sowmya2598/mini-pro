﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eshoppyEntities
{
    public class ProductOrders
    {
        public int POId { get; set; }
        public String ProductOrderId { get; set; }
        public string ProductId { get; set; }
        public DateTime ExpectedDeliveryDate { get; set; }
        public string CustomerId { get; set; }
        public string DealerCode { get; set; }
        public string DispatchedStatus { get; set; }


    }
}
