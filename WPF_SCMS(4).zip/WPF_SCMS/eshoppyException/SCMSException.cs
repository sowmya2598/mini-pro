﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eshoppyException
{
    public class SCMSException: ApplicationException
    {
        public SCMSException() : base()
        {

        }

        public SCMSException(string message) : base(message)
        {

        }
    }
}
