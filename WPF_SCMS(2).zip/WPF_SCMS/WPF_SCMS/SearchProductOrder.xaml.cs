﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using eshoppyBL;
using eshoppyEntities;
using eshoppyException;


namespace WPF_SCMS
{
    /// <summary>
    /// Interaction logic for SearchProductOrder.xaml
    /// </summary>
    public partial class SearchProductOrder : Page
    {
        public SearchProductOrder()
        {
            InitializeComponent();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {

            try
            {
                ProductOrders productorderSearched = null;
                if (txtProductOrderId.Text == "")
                    productorderSearched = SCMSBL.SearchProductOrderBAL(Convert.ToInt32(txtProductOrderId.Text));
                //else
                //    productorderSearched = SCMSBL.SearchProductOrderBAL(Convert.ToInt32(txtProductId.Text));
                if (productorderSearched != null)
                {
                    txtProductId.Text = productorderSearched.ProductId.ToString();
                    txtCustomerId.Text = productorderSearched.CustomerId.ToString();
                    txtExpextedDeliveryDate.Text = productorderSearched.ExpectedDeliveryDate.ToString();
               


                }
                else
                {
                    MessageBox.Show("ProductOrder not found");
                }
            }
            catch (SCMSException eex)
            {
                MessageBox.Show(eex.Message);
            }
        }
    }
}
