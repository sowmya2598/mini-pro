﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using eshoppyBL;
using eshoppyEntities;
using eshoppyException;

namespace WPF_SCMS
{
    /// <summary>
    /// Interaction logic for SearchProduct.xaml
    /// </summary>
    public partial class SearchProduct : Page
    {
        public SearchProduct()
        {
            InitializeComponent();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            try
            {
                Products productSearched = null;
                if (txtProductName.Text == "")
                    productSearched = SCMSBL.SearchProductBAL(Convert.ToInt32(txtProductId.Text));
                else
                    productSearched = SCMSBL.SearchProductBAL(Convert.ToInt32(txtProductName.Text));
                if (productSearched != null)
                {
                    txtProductName.Text = productSearched.ProductName;
                    txtQuantity.Text = productSearched.Quantity.ToString();
                    txtPrice.Text = productSearched.Price.ToString();
                    cdbProductAddDateTime.DataContext = productSearched.ProductAddDateTime;


                }
                else
                {
                    MessageBox.Show("Product not found");
                }
            }
            catch (SCMSException eex)
            {
                MessageBox.Show(eex.Message);
            }
        }
    }
}
