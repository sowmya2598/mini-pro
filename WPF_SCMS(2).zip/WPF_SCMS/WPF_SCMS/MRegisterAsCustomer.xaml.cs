﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using eshoppyBL;
using eshoppyEntities;
using eshoppyException;


namespace WPF_SCMS
{
    /// <summary>
    /// Interaction logic for MRegisterAsCustomer.xaml
    /// </summary>
    public partial class MRegisterAsCustomer : Window
    {
        public MRegisterAsCustomer()
        {
            InitializeComponent();
        }

        private void BtnRegisterAsCustomer_Click(object sender, RoutedEventArgs e)
        {
            Customers newcustomer = new Customers();
            try
            {

                newcustomer.OrganizationName = txtOrganizationName.Text;
                newcustomer.ContactPerson = txtContactPerson.Text;
                newcustomer.ContactNumber = Convert.ToInt32(txtContactNumber.Text);
                newcustomer.DeliveryAddress = txtDeliveryAddress.Text;
                newcustomer.OfficialEmail = txtOfficialEmail.Text;
                newcustomer.Username = txtCustomerUserName.Text;
                newcustomer.Password = txtCustomerPassword.Password;


                if (SCMSBL.RegisterAsCustomerBAL(newcustomer))
                    MessageBox.Show("Customer Registered Successfully..!");
                else
                    MessageBox.Show("Cannot Register As Customer ");
            }
            catch (SCMSException sex)
            {
                MessageBox.Show(sex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnClearCustomer_Click(object sender, RoutedEventArgs e)
        {
            txtOrganizationName.Clear();
            txtContactPerson.Clear();
            txtContactNumber.Clear();
            txtDeliveryAddress.Clear();
            txtOfficialEmail.Clear();
            txtCustomerUserName.Clear();
            txtCustomerPassword.Clear();
        }
    }
}
