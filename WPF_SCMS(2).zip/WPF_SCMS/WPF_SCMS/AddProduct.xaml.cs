﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using eshoppyEntities;
using eshoppyBL;
using eshoppyException;

namespace WPF_SCMS
{
    /// <summary>
    /// Interaction logic for AddProduct.xaml
    /// </summary>
    public partial class AddProduct : Page
    {
        public AddProduct()
        {
            InitializeComponent();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Products newproduct = new Products();
            try
            {
               
                newproduct.ProductName = txtProductName.Text;
                newproduct.Quantity = Convert.ToInt32(txtQuantity.Text);
                newproduct.Price = Convert.ToInt32(txtPrice.Text);
                newproduct.ProductAddDateTime = Convert.ToDateTime(cdbProductAddDateTime);
                
                if (SCMSBL.AddProductBAL(newproduct))
                    MessageBox.Show("Product Added Successfully..!");
                else
                    MessageBox.Show("Cannot Add Product");
            }
            catch (SCMSException sex)
            {
                MessageBox.Show(sex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
